var gURL="";
var deviceId = encrypt(checkNull(sessionStorage.getItem("deviceid")));
var env = "DEV";
var encFlag = true;
var clientVersion = "4.0";

class Loginpage extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersLogin:[]
       }
	
	 
     }
	
 
  
   completeregistration = () =>
	{
       
		 this.insertUser1();
	}

	

insertUser1 = () => {

			 if (deviceId == "")
					deviceId = encrypt("1234567890");
				
			  if (devicePlatform == "")
					devicePlatform = "iOS";
      
				var clientVerWithOS = devicePlatform + "###" + clientVersion;
				
				sessionStorage.setItem("customerEmailID", "as@gmail.com");
				 alert(document.getElementById("inputFirstname").value);
				var search = {}
				search["name1"] = document.getElementById("inputFirstname").value;
				search["name2"] = document.getElementById("inputLastname").value;
				search["nric"] = "G508569";//document.getElementById("nirc").value;
				search["gender"] = document.getElementById("gender").value;
				search["birth"] = document.getElementById("inputBirthdate").value;
				search["mobile"] = "98991478";//document.getElementById("inputMobile").value;
				search["email"] = document.getElementById("inputEmail").value;
				search["password"] = document.getElementById("inputPassword").value;
               	search["deviceId"] = getSessionID();
				search["clientVersion"] = clientVerWithOS;
			   
				$.ajax({
					type: "POST",
					contentType: "application/json",
					url: "/api/userinsert",
					data: JSON.stringify(search),
					dataType: 'json',
					cache: false,
					timeout: 600000,
					success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						
					  this.setState({
						   usersLogin:obj
						})
                     
						//  sessionStorage.setItem("cusId", this.props.usersLogin);
					location.href="http://localhost:8080";
				
					
					}
				});
	     }

   render() {
   return (
      <div>
        <div id="blur_model" className="modal-blur" style={{display: 'none'}} />
        <section className="page-container inner-wrapper clearfix">
          <article>
            <h1>Hello!</h1>
            <h2>Thanks for the mobile number verification. We just need a few other details from you.</h2>
          </article>
          <aside />
          <form action="#" method id="register-form">
            <article className="text-data">
              <div className="register-text input clearfix" data-message>	
                <label>Title</label>						
                <div className="double mobile-dropdown desktop-element">
                  <span className="dropdown-overlay">
                    <div className="overlay">Mr</div>
                    <select id="title" className="title-select">
                    </select>
                  </span>
                </div>
                <span className="error-span error-message" /> 
              </div>
              <div className="register-text input clearfix" data-message>	
                <label>Name</label>
                <div className="double">
                  <input type="text" id="inputFirstname" maxLength={50} placeholder="First name" className="test" />
                  <input type="text" id="inputLastname" maxLength={50} placeholder="Last name" className="test" />
                </div>						
                <span className="error-span" />
              </div>
              <div className="register-text input single clearfix" data-message>	
                <label htmlFor="nric" style={{width: 'inherit'}}>NRIC/FIN/Passport Number</label>
                <input type="text" id="nric" placeholder="Your customer ID and cannot be changed" style={{width: '250px'}} name="nirc" />
                <span className="error-span" />
              </div>
              <div className="register-text input clearfix" data-message>	
                <label>Gender</label>						
                <div className="double mobile-dropdown desktop-element">
                  <span className="dropdown-overlay">
                    <div className="overlay gender">Select</div>
                    <select id="gender" className="gender-select">
                      <option value disabled="disabled" selected="selected">Select</option>
                      <option value="M">Male</option>
                      <option value="F">Female</option>
                    </select>
                  </span>
                </div>
                <span className="error-span" /> 
              </div>
              <div className="register-text input clearfix" data-message> 	
                <label htmlFor="inputBirthdate">Birthday</label>
                <input type="text" id="inputBirthdate" placeholder="DD/MM/YYYY" className="test" />
                <span className="error-span error-message" />
              </div>
              <div className="register-text input single clearfix" data-message>	
                <label htmlFor="inputMobile">Mobile</label>
                <div className="text-wrap" style={{minHeight: '66px'}} data-message>
                  <input type="text" id="inputBirthdate" placeholder={+6598991478} className="test" />
                  <span className="error-span error-message" />
                </div>
              </div>
              <div className="register-text input single clearfix" data-message>	
                <label htmlFor="inputEmail">Email (Username)</label>
                <input type="text" id="inputEmail" maxLength={50} placeholder="email@example.com" name="email" className="test" />
                <span className="error-span" />
              </div>
              <div className="register-text input single clearfix" data-message>	
                <label htmlFor="inputConfirmEmail">Confirm email</label>						
                <input type="text" id="inputConfirmEmail" maxLength={50} placeholder className="test" />
                <span className="error-span" />
              </div>
              <div className="register-text single input clearfix" data-message>	
                <label htmlFor="inputPassword">Password</label>
                <input type="password" id="inputPassword" maxLength={20} placeholder className="test" />
                <span className="error-span error-message" />
              </div>
              <div className="register-text single input clearfix" data-message>	
                <label htmlFor="inputConfirmPassword">Confirm password</label>
                <input type="password" id="inputConfirmPassword" maxLength={20} placeholder className="test" />
                <span className="error-span error-message" />
              </div>			
              <div className="register-text single clearfix">	
                <label htmlFor="tcpp" className="hide-label no">Terms &amp; Conditions and Privacy Policy</label>
                <div className="checkbox-button double">	
                  <input type="checkBox" className="check" id="tcChk" />
                  <p className="text">I agree to the UOB Group's <a href="###" >Terms &amp; Conditions </a> 
                    and <a href="###" >Privacy Policy</a>
                  </p>
                </div>	
              </div>
              <div className="btn-normal btn-login btn-register button"  onClick={this.completeregistration}><span>Complete registration</span></div>
            </article>	
          </form>
        </section>
      </div>
    );
  
 }
}

ReactDOM.render(<Loginpage />, document.getElementById('root1'));


function getUserPhone()
{
  location.href="js/newcustomer.html";

}

