class App extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersStmtListDetails:[],
       }
	 }
	
  handelClickDwnPDF = () =>
	{
       
		 downloadPdf();
	}


  componentDidMount()
	{
                
		 this.getStatementListData();
	}
getStatementListData = () => {

	var cusId = sessionStorage.getItem("cusId");
	
	var cusSegmentId ="1234"; //sessionStorage.getItem("cusSegmentId");
	var cusLoginEmailId ="as@gmail.com";// sessionStorage.getItem("cusLoginEmailId");
	var cusFirstName = "SANJAY";sessionStorage.getItem("cusFirstName");
	var cusLastName = "KUMAR";sessionStorage.getItem("cusLastName");
	var custFullName = "SANJAY K";//sessionStorage.getItem("custFullName");
	var cusMobileNumber = "98991478"//sessionStorage.getItem("cusMobileNumber");
    var search = {}
    search["cusId"] = cusId;
	search["pass"] = cusSegmentId;
	search["deviceId"] = cusLoginEmailId;
    search["clientVersion"] = cusFirstName;
  
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/transdet",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
       	success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						console.log(obj.stmtLst);
						//console.log(obj.otherDetaisLst[0]);
						//console.log(obj.stmtLst[1]);
					  this.setState({
						   usersStmtListDetails:obj.stmtLst,
						  // usersStmtDetails2:obj.otherDetaisLst[0]
						})
                     
					  // console.log(this.state.usersStmtDetails.productId);
					 //  sessionStorage.setItem("cusId", this.props.usersStmtDetails);
				//	  location.href="js/index_listing.html?cifid=" + this.state.usersStmtDetails.cusId;
				
					
					}
				});
	     }
  
  render() {
   
   // const { usersStmtListDetails } = this.state
		 console.log("usersStmtDetails>>>>"+this.state.usersStmtListDetails.length);
    /*const dashboardlistarray = [
	
	{
		  id: Date,
		  RefNo: 'HSBC:142521566060:id345',
		  Date: '07 Jun 2019',
		  Debit: '$15.20', 
		  Credit: '$15.20'
	  },	
	  {
		  id: 1,
		  RefNo: 'HSBC:142521566060:id345',
		  Date: '07 Jun 2019',
		  Debit: '$225.20', 
		  Credit: '$15.20'
	  },
	 {
		  id: 2,
		  RefNo: 'HSBC:142521566060:id345',
		  Date: '07 Jun 2019',
		  Debit: '111', 
		  Credit: '$15.20'
	  }
	
	 
	]*/

   const arraydashboardcard = this.state.usersStmtListDetails.map( (dashboardcard, i) =>  {
   
    return (
      <div >
           {(i == 0 ? 
		 <table className="pricing" style={{fontSize: '16px', lineHeight: '23px', padding: '23px 0',width: '100%',}}>
                  <tbody>
	         <tr className="final-price">

			          <td style={{textAlign: 'left', width: '10%'}}>Location</td>
			          <td style={{textAlign: 'center', width: '10%'}}>Temp</td>
                      <td style={{lineHeight: '23px', padding: '23px 0', width: '40%',textAlign: 'left'}}>Wind Speed</td>
                       <td style={{textAlign: 'right', width: '20%'}}>Humidity</td>
                      <td style={{textAlign: 'right', width: '20%'}}>Pressure</td>			
                    </tr> 
			 </tbody>
                </table>
	        :
			    <tr>
		          
			          <td style={{textAlign: 'left', width: '10%'}}>{dashboardcard.transDate} </td>
			          <td style={{textAlign: 'center', width: '12%'}}>{dashboardcard.strCode} </td>
		              <td style={{lineHeight: '23px', padding: '23px 0', width: '57%',textAlign: 'left'}}>{dashboardcard.strRefNo}</td>
                      <td style={{textAlign: 'left', width: '70%'}} >{dashboardcard.strDebitAmt}</td>
                      <td style={{textAlign: 'right', width: '80%'}}>{dashboardcard.strCreditAmt}</td>			
                    </tr>
                   
             )}    
      </div>
    );
    } )

   return (
       <div>
	   <div className="content-wrapper standard-page">
        <section className="page-container inner-wrapper clearfix payment-page" style={{padding: '65px 10px',maxWidth: '980px'}}>
          <div className="checkout-container" style={{width: '1058px', marginLeft: '4px',}}>
			 <a href="#" onClick={this.handelClickDwnPDF} style={{paddingLeft: "870px"}}><img src="images/download.png" style={{width: "28px", backgroundColor: "#f5f5f5"}} alt="Uob Logo" / ></a>  <span >  Download <img src="images/print.png" style={{width: "28px", backgroundColor: "#f5f5f5"}} alt="Uob Logo" / > Print </span>	
			
            <section className="order-summary">
              <h1 style={{padding: '23px 23px 23px 3px'}}>
                <span  >NEARBY WEATHER STATIONS</span>
              </h1>
              <div className="clearfix ">
           
                   
		            {arraydashboardcard}	
			   
                <div className="final-price" style={{textAlign: 'right', width: '100%'}}>Page 1,2,3.......</div>
              </div>
            </section>
          </div>
        </section>
      </div>
       </div>
      
    )
  
 }
}

ReactDOM.render(<App />, document.getElementById('root1'));



function downloadPdf()
{
  location.href="api/download1";

}