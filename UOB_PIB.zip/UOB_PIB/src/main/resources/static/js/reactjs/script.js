

class Loginpage extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersLogin:[]
       }
	
	 
     }
	
 
  
   handelClick = () =>
	{
        
		 this.authenticateUser1();
	}

	handelClickSignUp = () =>
	{
        
		getUserPhone();
	}

authenticateUser1 = () => {

			 if (deviceId == "")
					deviceId = encrypt("1234567890");
				
			  if (devicePlatform == "")
					devicePlatform = "iOS";

				var clientVerWithOS = devicePlatform + "###" + clientVersion;
				var email = encrypt(document.getElementById("loginEmail").value);
				var pass = encrypt(document.getElementById("loginPassword").value);
				sessionStorage.setItem("customerEmailID", document.getElementById("loginEmail").value);
				
				var search = {}
				search["email"] = document.getElementById("loginEmail").value;
				search["pass"] = document.getElementById("loginPassword").value;
				search["deviceId"] = getSessionID();
				search["clientVersion"] = clientVerWithOS;
			   
				$.ajax({
					type: "POST",
					contentType: "application/json",
					url: "/api/search",
					data: JSON.stringify(search),
					dataType: 'json',
					cache: false,
					timeout: 600000,
					success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						
					  this.setState({
						   usersLogin:obj
						})
                     
						//  sessionStorage.setItem("cusId", this.props.usersLogin);
					location.href="js/dash_bord.html"
				
					
					}
				});
	     }

   render() {
    return (

      <section className="login-modal" style={{display: 'block'}}>
        <div className="site-logo">
          <img src="js/images/uob-logo.png" className="main-logo" alt="uob-Logo" />
        </div>
        <form className="clearfix">
          <h1 className="visuallyhidden">Login</h1>
          <div className="text-wrap" data-message="Please enter your username.">
            <label htmlFor="loginEmail">Username (E-mail)</label>
            <input type="text" id="loginEmail" maxLength={50} defaultValue="as@gmail.com" />
          </div>
          <div className="text-wrap" data-message="Please enter your password.">
            <label htmlFor="loginPassword">Password</label>
            <input type="password" id="loginPassword" maxLength={20} defaultValue="admin@1234" />
          </div>
          <a href="#" onClick={this.handelClick} className="btn-login btn-normal"><span>Login</span></a>
        </form>	
        <div className="forgotten-password">
          <p><a href="#" onClick={this.handelClickSignUp} >Sign up</a> for a new account ?<br />Forgotten <a href="#">Username</a>&nbsp;or <a href="#">Password</a>&nbsp;?</p>
        </div>
        <div className="forgotten-password">
          <p /><h4 id="responseMsg" style={{display: 'none', color: 'red', textAlign: 'left'}} /><p />
        </div>
        <font color="#e9e9e9" />
      </section>
    );
  
 }
}

ReactDOM.render(<Loginpage />, document.getElementById('translator'));


function getUserPhone()
{
  location.href="js/newcustomer.html";

}

