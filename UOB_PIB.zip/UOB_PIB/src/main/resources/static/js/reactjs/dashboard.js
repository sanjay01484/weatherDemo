

class DashBoard extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersDashBoardDetails:[],
		strMethodName:"handelClick",
       }
		
	 }
	
 handelClick = (strMethodName) =>
	{
       if (strMethodName=="getTransDet")
       {
          getTransDet();
       }
      else{
	  	  location.href="index_listing.html";
	  }
		
	
	}
  
   componentDidMount()
	{
                
		 this.getDashBoardData();
	}
getDashBoardData = () => {

	var cusId = sessionStorage.getItem("cusId");
	
	var cusSegmentId ="1234"; //sessionStorage.getItem("cusSegmentId");
	var cusLoginEmailId ="as@gmail.com";// sessionStorage.getItem("cusLoginEmailId");
	var cusFirstName = "SANJAY";sessionStorage.getItem("cusFirstName");
	var cusLastName = "KUMAR";sessionStorage.getItem("cusLastName");
	var custFullName = "SANJAY K";//sessionStorage.getItem("custFullName");
	var cusMobileNumber = "98991478"//sessionStorage.getItem("cusMobileNumber");
    var search = {}
    search["cusId"] = cusId;
	search["pass"] = cusSegmentId;
	search["deviceId"] = cusLoginEmailId;
    search["clientVersion"] = cusFirstName;
  
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/dashboard",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
       	success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						console.log(obj.stmtLst);
						//console.log(obj.otherDetaisLst[0]);
						//console.log(obj.stmtLst[1]);
					  this.setState({
						   usersDashBoardDetails:obj.stmtLst,
						  // usersStmtDetails2:obj.otherDetaisLst[0]
						})
                     
					  // console.log(this.state.usersStmtDetails.productId);
					 //  sessionStorage.setItem("cusId", this.props.usersStmtDetails);
				//	  location.href="js/index_listing.html?cifid=" + this.state.usersStmtDetails.cusId;
				
					
					}
				});
	     }

  render() {

    const dashboardlistarray = [
		
	   {
	     id:1,
		 name:"DownLoad WeatheData",
		 Tyoe:"Download pdf"
	   
	   }
	]
   console.log("usersStmtDetails>>>>"+this.state.usersDashBoardDetails.length);

   const arraydashboardcard = this.state.usersDashBoardDetails.map( (dashboardcard, i) =>  {
     const arraydashboardcard = this.functionName
    return (
      <div style={{float: "left"}}>
        <a href="#"  onClick={this.handelClick.bind(this, dashboardcard.strMethodName)} className="tile-link">
          <article className="common-tile medium medium-height red-back">
            <h2 className="no-hover">{dashboardcard.strRefNo}</h2>
            <div className="hover-tile">
              <h3>{dashboardcard.strSubRefNo}</h3>
              <button className="arrow">hover-arrow</button>
            </div>
          </article>
        </a>
        
      </div>
    );
    } )

   return (
       <div>
		  {arraydashboardcard}	
       </div>
      
    )
  
 }
}



ReactDOM.render(<DashBoard />, document.getElementById('dashboard'));


function getTransDet()
{

  location.href="listdata.html"
}