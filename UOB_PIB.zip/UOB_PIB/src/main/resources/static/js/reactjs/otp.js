

class Loginpage extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersLogin:[]
       }
	
	 
     }
	
 
  
   next = () =>
	{
        
		location.href="register.html";
	}

	getNewCustomer = () =>
	{
        
		location.href="newcustomer.html";
	}

authenticateUser1 = () => {

			 if (deviceId == "")
					deviceId = encrypt("1234567890");
				
			  if (devicePlatform == "")
					devicePlatform = "iOS";

				var clientVerWithOS = devicePlatform + "###" + clientVersion;
				var email = encrypt(document.getElementById("loginEmail").value);
				var pass = encrypt(document.getElementById("loginPassword").value);
				sessionStorage.setItem("customerEmailID", document.getElementById("loginEmail").value);
				
				var search = {}
				search["email"] = document.getElementById("loginEmail").value;
				search["pass"] = document.getElementById("loginPassword").value;
				search["deviceId"] = getSessionID();
				search["clientVersion"] = clientVerWithOS;
			   
				$.ajax({
					type: "POST",
					contentType: "application/json",
					url: "/api/search",
					data: JSON.stringify(search),
					dataType: 'json',
					cache: false,
					timeout: 600000,
					success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						
					  this.setState({
						   usersLogin:obj
						})
                     
						//  sessionStorage.setItem("cusId", this.props.usersLogin);
					location.href="js/dash_bord.html"
				
					
					}
				});
	     }

   render() {
   return (
      <div>
        <div id="blur_model" className="modal-blur" style={{display: 'block'}} />
        <section className="login-modal" style={{display: 'block', top: 20, padding: '470px 70px 50px'}}>
          <span className="close-modal close-overlay">close-overlay</span>
          <form>
            <h2>Verification</h2>
            {/* h3>Check your phone, we have sent you a 6 digit OTP code to validate your number. Please enter it below.</h3 */}
            <h3>Please enter the 6-digit OTP that was just sent to your mobile number</h3>
            <div className="text-wrap" data-message style={{minHeight: '10px'}}>
              <label htmlFor="c" className="hide-class">send your mobile number</label>
              <input type="number" inputMode="numeric" pattern="[0-9]*" id="otpNumber" />
            </div>	
            <em id="resentMsg" className="erMsg" style={{display: 'none'}}>We resent you 6 digits code (OTP) on your mobile number.</em><br />
            <table width="100%">
              <tbody>
                <tr>
                  <td align="left" style={{float: 'left'}}>
                    <div  onClick={this.getNewCustomer} className="btn-login btn-normal" style={{marginTop: '0px', float: 'left', minWidth: 'inherit'}}><span>BACK</span>
                    </div>"&nbsp;&nbsp;"
                  </td>
                  <td align="left" style={{float: 'left'}}>
                    <div onClick="alert('under construction')" className="btn-login btn-normal" style={{marginTop: '0px', float: 'left', minWidth: 'inherit'}}><span>RESEND OTP</span>
                    </div>
                  </td>
                  <td align="right">
                    <div className="btn-login btn-normal otp-button" style={{marginTop: '0px', minWidth: 'inherit'}} onClick={this.next}><span>verify</span></div>
                  </td>
                </tr>
              </tbody>
            </table>
          </form>	
        </section>
      </div>
    );
  
 }
}

ReactDOM.render(<Loginpage />, document.getElementById('root1'));


function getUserPhone()
{
  location.href="js/newcustomer.html";

}

