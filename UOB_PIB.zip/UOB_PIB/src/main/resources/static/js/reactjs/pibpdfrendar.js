

class Pdfpage extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersStmtListDetails:[],
       }
	 }

	handelClickDwnPDF = () =>
	{
       
		 downloadPdf();
	}


  componentDidMount()
	{
                
		 this.getStatementListData();
	}
getStatementListData = () => {

	var cusId = sessionStorage.getItem("cusId");
	
	var cusSegmentId ="1234"; //sessionStorage.getItem("cusSegmentId");
	var cusLoginEmailId ="as@gmail.com";// sessionStorage.getItem("cusLoginEmailId");
	var cusFirstName = "SANJAY";sessionStorage.getItem("cusFirstName");
	var cusLastName = "KUMAR";sessionStorage.getItem("cusLastName");
	var custFullName = "SANJAY K";//sessionStorage.getItem("custFullName");
	var cusMobileNumber = "98991478"//sessionStorage.getItem("cusMobileNumber");
    var search = {}
    search["cusId"] = cusId;
	search["pass"] = cusSegmentId;
	search["deviceId"] = cusLoginEmailId;
    search["clientVersion"] = cusFirstName;
  
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/userdet",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
       	success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						console.log(obj.stmtLst);
						//console.log(obj.otherDetaisLst[0]);
						//console.log(obj.stmtLst[1]);
					  this.setState({
						   usersStmtListDetails:obj.stmtLst,
						  // usersStmtDetails2:obj.otherDetaisLst[0]
						})
                     
								}
				});
	     }
  
  render() {
   
  
		 console.log("usersStmtDetails>>>>"+this.state.usersStmtListDetails.length);
  
   const arraydashboardcard = this.state.usersStmtListDetails.map( (statementlist, i) =>  {
   
    return (
   
		 
	     <div>
            <div className="share-container" style={{display: 'none'}}>
               <span className="share clearfix" style={{position: 'inherit'}} > <em>Share via</em>
		          <a href="#" onclick="shareOnSocialMedia('FB')"><img src="../../images/sprites-general.png" className="tw" alt="tw-share" />twitter</a>
                  <a href="#" onclick="shareOnSocialMedia('FB')"><img src="../../images/sprites-general.png" className="fb" alt="fb-share" />facebook</a>
               </span>
		    </div>
            <section className="clearfix" style={{display: 'block',padding: "10px 0 10px 10px"}}><h4>May Month <em style={{paddingTop: '10px'}}> {statementlist.productName}</em> 
              <span className="cart service book">
                <div><p style={{textAlign: 'left', marginBottom: '0px'}}>Weather</p></div>
                  <a href="#" onClick={this.handelClickDwnPDF} className="btn-normal item-added">
                  <img src="../../images/sprites-general.png" className="desktop-element" />Download Pdf </a ></span></h4>
			 </section>
		    </div>
		 
    );
    } )

   return (
       <div className="App">
       <article>
         <div className="list-header active">  <h3>Monthly Weather Data </h3> <div className="expand">expand symbol</div></div>
	                   
		            {arraydashboardcard}	
			   
            
      </article>
      </div>
      
    )
  
 }
}
ReactDOM.render(<Pdfpage />, document.getElementById('treatment-container-list'));


function downloadPdf()
{
  location.href="api/download1";

}