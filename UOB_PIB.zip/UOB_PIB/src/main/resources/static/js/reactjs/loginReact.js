class Loginpage extends React.Component {
 render() {
    return <h1>Hello</h1>);
  
 }
}
export default Loginpage;

