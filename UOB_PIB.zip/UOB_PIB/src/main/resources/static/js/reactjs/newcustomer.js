

class Loginpage extends React.Component {
	
	 constructor(props){
       super(props);
        this.state={
        usersLogin:[]
       }
	
	 
     }
	
 
  
   next = () =>
	{
        
		location.href="otp-page.html";
	}

	getNewCustomer = () =>
	{
        
		location.href="http://localhost:8080/";
	}

authenticateUser1 = () => {

			 if (deviceId == "")
					deviceId = encrypt("1234567890");
				
			  if (devicePlatform == "")
					devicePlatform = "iOS";

				var clientVerWithOS = devicePlatform + "###" + clientVersion;
				var email = encrypt(document.getElementById("loginEmail").value);
				var pass = encrypt(document.getElementById("loginPassword").value);
				sessionStorage.setItem("customerEmailID", document.getElementById("loginEmail").value);
				
				var search = {}
				search["email"] = document.getElementById("loginEmail").value;
				search["pass"] = document.getElementById("loginPassword").value;
				search["deviceId"] = getSessionID();
				search["clientVersion"] = clientVerWithOS;
			   
				$.ajax({
					type: "POST",
					contentType: "application/json",
					url: "/api/search",
					data: JSON.stringify(search),
					dataType: 'json',
					cache: false,
					timeout: 600000,
					success: (data) => {
						  var str = data.toString();
						   var obj = eval ("(" + str + ")"); 
						
					  this.setState({
						   usersLogin:obj
						})
                     
						//  sessionStorage.setItem("cusId", this.props.usersLogin);
					location.href="js/dash_bord.html"
				
					
					}
				});
	     }

   render() {
    return (
     <div>
		<div id="blur_model" className="modal-blur" style={{display: 'block'}} />
      <section className="login-modal" style={{display: "block", top: "20", padding: '470px 70px 50px'}}>
        <span className="close-modal close-overlay">close-overlay</span>
        <form>
          <h2>Hello! Let's get started.</h2>
          <h3>Please enter your mobile number.</h3>
          <div className="text-wrap" style={{minHeight: "66px"}} data-message>
            <table width="100%">
              <tbody><tr>
                  <td valign="top" align="left" style={{paddingTop: "19", paddingRight: "0"}}>
                    <input type="number" inputMode="numeric" pattern="[0-9]*" id="mobileNumber" style={{verticalAlign: "top", marginTop: "0", marginBottom: "10", paddingTop: "0, top: 0", float: "right"}} />
                  </td>
                </tr>
              </tbody></table>
          </div>	
          <em id="responseMsg" className="erMsg" style={{display: "none"}} />
          <table width="100%">
            <tbody>
              <tr>
                <td align="left" style={{float: 'left'}}>
                  <div  onClick={this.getNewCustomer} className="btn-login btn-normal" style={{marginTop: "0px", float: "left", minWidth: "inherit"}}><span>BACK</span>
                  </div>&nbsp;&nbsp;
                </td>
                <td align="right">
                  <div className="btn-login btn-normal otp-button" style={{marginTop: '0px', minWidth: 'inherit'}} onClick={this.next}><span>NEXT</span></div>
                </td>
              </tr>
            </tbody>
          </table>
        </form>	
      </section>
					 </div>
    );
  
 }
}

ReactDOM.render(<Loginpage />, document.getElementById('root1'));


function getUserPhone()
{
  location.href="js/newcustomer.html";

}

