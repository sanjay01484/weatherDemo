/*! seg-git 2014-11-04 */
(function($) {
/*	$(".app-welcome-page .btn-login").click(function(e) {
        e.preventDefault();
        $(".app-welcome-page .brands").css({
            position: "relative"
        });
        $(".app-welcome-page .login-modal").slideUp(function() {
            $(".app-welcome-page .content-wrapper").css({
                "padding-top": 0
            });
        });
    });	*/
    $(".js-add-to-cart").click(function(e) {
        e.preventDefault();
        if ($(".cart-list").is(":visible")) {
            $(".cart-list .cart-value").html("(3)");
            $(".cart-list a").addClass("active");
            setTimeout(function() {
                $(".cart-list a").removeClass("active");
            }, 5e3);
        }
        $(this).find("span").text("add again");
        $(this).addClass("active");
    });
    (function() {
        var mobileMenuButton = $(".btn-mobile-menu"), navBar = $(".nav-bar, .account-bar"), $containerSlideDown = $(".brand-container, .content-wrapper");
        mobileMenuButton.on("click", function() {
            navBar.slideToggle("normal");
            $(this).toggleClass("active-menu-button");
            $containerSlideDown.toggleClass("slideDownContainer");
        });
    })();
    (function() {
        var dropdownSelect = $(".dropdown-overlay").find("select"), navBar = $(".nav-bar, .account-bar"), replaceText, divOverlay;
        dropdownSelect.on("change", function() {
            replaceText = $(this).find("option:selected").text();
            divOverlay = $(this).prev();
            divOverlay.html("<span>" + replaceText + "</span>");
        });
    })();
    (function() {
        var $useButton = $(".account-bar > li:first-child > a"), $ordersDropdown = $(".internal-bar"), $notArea = $(".account-bar > li:first-child > a, .internal-bar > li > a");
        if ($(window).width() > 992) {
            $useButton.on("mouseover", function() {
                $ordersDropdown.stop().clearQueue().slideDown("normal");
            }).on("mouseout", function() {
                $ordersDropdown.stop().clearQueue().slideUp("normal");
            });
            $ordersDropdown.on("mouseover", function() {
                $ordersDropdown.stop().clearQueue().slideDown("normal");
            }).on("mouseout", function() {
                $ordersDropdown.stop().clearQueue().slideUp("normal");
            });
        }
        var $cartItem = $(".item-data"), $grandTotal = $(".login-modal strong"), $input = $(".quant");
        $remove = $(".js-remove-item");
        grandTotal = 0;
        $remove.on("click", function() {
            $(this).parent().parent().slideUp(function() {
                $(this).remove();
                updateGrandTotal();
            });
        });
        $input.on("change", function() {
            var $this = $(this);
            if (!isNaN($this.val())) {
                $this.val(parseInt($this.val())).removeClass("warning");
                total = Number($this.parent().data("cost")) * $this.val();
                if (total == 0) $this.parent().find(".js-remove-item").trigger("click");
            } else {
                $this.val(0).addClass("warning");
                total = Number($this.parent().data("cost")) * 0;
            }
            total = Math.round(total * 100) / 100;
            $this.parent().find("p").text("$" + total);
            updateGrandTotal();
        });
        updateList();
        function updateList() {
            $input.each(function() {
                var $this = $(this);
                total = Number($this.parent().data("cost")) * $this.val();
                total = Math.round(total * 100) / 100;
                $this.parent().find("p").text("$" + total);
                updateGrandTotal();
            });
        }
        function updateGrandTotal() {
            $input = $(".quant"), grandTotal = 0;
            $input.each(function() {
                var itemPrice = $(this).parent().find("p").text();
                itemPrice = Number(itemPrice.replace("$", ""));
                grandTotal += itemPrice;
            });
            $grandTotal.text("$" + grandTotal);
        }
    })();
    (function() {
        var $container = $(".masonry");
        if ($(window).width() >= 768) {
            $container.masonry({
                columnWidth: 1,
                gutter: 10
            });
        }
    })();
    (function() {
        var $accountCart = $(".account-bar >li:last-child a");
        if ($(window).width() <= 992) {
            $accountCart.addClass("btn-normal");
        }
    })();
    (function() {})();
    (function() {
        var $selectLink = $(".listing-container").find(".category-tab.listing-tab"), $listingContent = $(".page-container.list-datatext"), $itemContainer = $(".text-data.list"), $firstChild = $itemContainer.find("> article:first-child"), headerText1 = '<article><div class="list-header"><h3>', headerText2 = '</h3> <div class="expand">expand symbol</div></div>', sectionText1 = '<section class="clearfix"><h4>', sectionText2Redeem = '</h4><div class="share-container"><span class="share clearfix"><em>Share via</em><a href="#" ><img src="../../images/sprites-general.png" class="tw" alt="tw-share"/>twitter</a><a href="#" ><img src="../../images/sprites-general.png" class="fb" alt="fb-share"/>facebook</a><a href="#" ><img src="../../images/sprites-general.png" class="mail" alt="mail-share"/>mail</a></span> </div><p class="redeem"><span class="redeem-icon text-hide">redeem icon</span>Part of your packages. You can redeem at checkout</p> <em>Duration: 5min</em><span class="cart service book"><div> <p>', sectionText2 = '</h4><div class="share-container"><span class="share clearfix"><em>Share via</em><a href="#" ><img src="../../images/sprites-general.png" class="tw" alt="tw-share"/>twitter</a><a href="#" ><img src="../../images/sprites-general.png" class="fb" alt="fb-share"/>facebook</a><a href="#" ><img src="../../images/sprites-general.png" class="mail" alt="mail-share"/>mail</a></span> </div><em>Duration: 5min</em><span class="cart service book"><div> <p>', sectionText3 = "</p><em>", sectionText4 = '</em></div> <a href="../../bookings/index.html" class="btn-normal"><img src="../../images/sprites-general.png" class="desktop-element">Book</a></span></section></article>', url = window.location.href;
        var categoryNumber = url.slice(-1);
        $selectLink.each(function() {
            if ($(this).attr("data-category") == categoryNumber) {
                $(this).find(" > a").addClass("active-box-tab");
                return false;
            }
        });
        $(init);
        function init() {
            $.getJSON("../../assets/seg/js/profile-data.json", processResult);
        }
        $selectLink.on("click", function() {
            $selectLink.find(" > a").removeClass("active-box-tab");
            $(this).find(" > a").addClass("active-box-tab");
            dataType = $(this).attr("data-type");
            categoryNumber = $(this).attr("data-category");
            $itemContainer.find("article").remove().slideUp();
            $(init);
            function init() {
                $.getJSON("../../assets/seg/js/profile-data.json", processResult);
            }
            $itemContainer.find("article:first-child .list-header").addClass("active");
        });
        function processResult(data) {
            for (var i in data.categories) {
                catElement = data.categories;
                if (i === categoryNumber) {
					console.log("catElement[categoryNumber].catName=="+catElement[categoryNumber].catName);
                    $listingContent.find("h1").text(catElement[categoryNumber].catName);
                    internalElement = catElement[categoryNumber].catType;
					console.log("internalElement=="+internalElement);
                    for (var j in internalElement) {
                        $itemContainer.append(headerText1 + internalElement[j].subTypeName + headerText2);
                        itemData = internalElement[j].subTypeData;
                        for (var k in itemData) {
                            if (itemData[k].redeem == 1) {
                                $itemContainer.find("article").eq(j).append(sectionText1 + itemData[k].name + sectionText2Redeem + itemData[k].price + sectionText3 + itemData[k].discount + sectionText4);
                            } else {
                                $itemContainer.find("article").eq(j).append(sectionText1 + itemData[k].name + sectionText2 + itemData[k].price + sectionText3 + itemData[k].discount + sectionText4);
                            }
                        }
                    }
                }
            }
            $itemContainer.find("> article:first-child").children().slideDown();
            $itemContainer.find("> article:first-child > .list-header").addClass("active");
        }
    })();
    (function() {
        var $shareContainer = $(".text-data.list");
        $shareContainer.on("click", ".share", function() {
            var $shareBox = $(this);
            $shareBox.css("width", "165");
        });
        $shareContainer.on("mouseleave", "section", function() {
            $(this).find(".share").css("width", "75");
        });
        $shareContainer.on("click", ".list-header", function() {
            $(this).toggleClass("active");
            $(this).siblings().slideToggle();
        });
    })();
    (function() {
        var $bookingMobile = $(".booking-blocks").find("> span"), $bookingStylist = $(".booking-blocks.who-block").find(".booking-button.summary"), $bookingMobileBlocks = $(".booking-blocks"), $bookingMobileCheckout = $(".booking-data-container.checkout-block"), $bookingMobileButton = $(".booking-blocks").find(".booking-button:not(.month-button)"), $monthButton = $(".booking-blocks").find(".booking-button.month-button");
        if ($(window).width() <= 768) {
            $bookingMobileBlocks.removeClass("booking-active");
            $bookingMobile.on("click", function(evt) {
                evt.preventDefault();
                var $this = $(this), linkIndex = $this.parent().index() - 1, scrollLink = $(".booking-blocks").get(linkIndex);
                $this.parent().toggleClass("booking-active");
                $this.next("div").slideToggle("normal");
                $("body").scrollTo(scrollLink, {
                    duration: 1e3
                });
            });
            $bookingMobileButton.on("click", function(evt) {
                evt.preventDefault();
                var $this = $(this), linkIndex = $this.parent().parent().index(), scrollLink = $(".booking-blocks").get(linkIndex);
                $mainBookingBlock = $this.parent().parent().next(".booking-blocks");
                $this.parent().slideUp(function() {
                    $("body").scrollTo(scrollLink, {
                        duration: 1e3
                    });
                }).parent().removeClass("booking-active");
                $mainBookingBlock.addClass("booking-active").find(".mobile-element").slideDown();
                if ($this.hasClass("summary")) {
                    $bookingMobileCheckout.slideDown(function() {
                        $("body").scrollTo($(".checkout-block"), {
                            duration: 1e3
                        });
                    });
                } else {}
            });
            $monthButton.on("click", function() {
                $monthButton.removeClass("active");
                $(this).addClass("active");
            });
            $bookingStylist.on("click", function() {
                $bookingMobileCheckout.slideDown();
            });
        }
    })();
    (function() {
        var $stylistFunction = $(".booking-blocks.who-block"), $stylistdropdown = $(".booking-blocks.who-block .dropdown-overlay").find(".stylist-dropdown"), flag = 0;
        if ($(window).width() <= 768) {
            $stylistFunction.find(".button-who").on("click", function() {
                stylistName = $(this).prev().val();
                $stylistdropdown.find("option").each(function() {
                    if ($(this).val().toLowerCase() === stylistName.toLowerCase()) {
                        $stylistdropdown.prev().text(stylistName);
                        flag = 1;
                        return false;
                    } else {
                        flag = 0;
                    }
                });
                if (flag === 0) {
                    $stylistdropdown.append('<option value="' + stylistName + '">' + stylistName + "</option>");
                    $stylistdropdown.prev().text(stylistName);
                }
            });
        }
    })();
    (function() {
        var $firstStylist = $(".detox").find(".regular-checkbox"), $secondStylist = $(".scrub").find(".regular-checkbox"), $updateStylistName = $(".booking-blocks.who-block");
        if ($(window).width() > 768) {
            $firstStylist.change(function() {
                firstName = $(this).val();
                $updateStylistName.find(".stylist1").text(firstName);
            });
            $secondStylist.change(function() {
                secondName = $(this).val();
                $updateStylistName.find(".stylist2").text(", " + secondName);
            });
        }
    })();
    (function() {
        var monthArray = [];
        monthArray[0] = "October";
        monthArray[1] = "November";
        monthArray[2] = "December";
        var $monthHeader = $(".when-block").find(".month-header"), $nextArrow = $(".when-block").find(".next"), $prevArrow = $(".when-block").find(".prev"), $firstText = $(".when-block").find(".first"), $secondText = $(".when-block").find(".second"), $thirdText = $(".when-block").find(".third"), $getDate = $(".date-block"), $getHours = $(".time-wrapper .hours").find(".active"), $getMinutes = $(".time-wrapper .minutes").find(".active"), idx = 0;
        if ($(window).width() > 768) {
            $(".date-block[data-month=0]").show();
            $monthHeader.text(monthArray[idx]);
            $prevArrow.hide();
            $nextArrow.on("click", function() {
                $prevArrow.show();
                idx++;
                $monthHeader.text(monthArray[idx]);
                $firstText.text(monthArray[idx]);
                if (idx > 1) {
                    $nextArrow.hide();
                }
                changeMonth(idx);
            });
            $prevArrow.on("click", function() {
                $nextArrow.show();
                idx--;
                $monthHeader.text(monthArray[idx]);
                $firstText.text(monthArray[idx]);
                if (idx <= 0) {
                    $prevArrow.hide();
                }
                changeMonth(idx);
            });
            function changeMonth(idx) {
                $getDate.slideUp();
                $getDate.each(function() {
                    if ($(this).attr("data-month") == idx) {
                        $(this).slideDown();
                        return false;
                    }
                });
            }
            $getDate.on("click", ".active-dates", function() {
                selectedItem = $(this).find("h4").text();
                $secondText.text(", " + selectedItem);
            });
            $getMinutes.on("click", function() {
                selectedItem = $(this).find("p").text();
                $thirdText.text(", " + selectedItem);
            });
        }
    })();
    (function() {
        var activeLinkFooter = $(".upper-footer").find("li a"), $spanDropdown = $(".upper-footer-dropdown");
        $spanDropdown.on("click", function() {
            $(this).nextAll("li").slideDown("normal");
            activeLinkFooter.on("click", function() {
                $spanDropdown.text($(this).text());
                $spanDropdown.nextAll("li:not(first-child)").slideUp();
            });
        });
        activeLinkFooter.each(function() {
            if ($(this).hasClass("active-footer-link") === true) {
                $spanDropdown.text($(this).text());
            }
        });
    })();
    (function() {
        var $allBookingContainers = $(".booking-data-container"), $whoContainer = $(".booking-data-container.who-block"), $whenContainer = $(".booking-data-container.when-block"), $checkoutContainer = $(".booking-data-container.checkout-block"), $bookingTab = $(".booking-blocks"), $mainTabs = $(".booking-blocks.where-block, .booking-blocks.when-block, .booking-blocks.who-block"), $who = $(".booking-blocks.who-block"), $when = $(".booking-blocks.when-block"), $where = $(".booking-blocks.where-block"), $whoTab = $(".who-tab"), $allFooters = $(".upper-footer,.site-footer ");
        $bookingHeader = $(".booking-header"), $minuteSelect = $(".date-wrapper").find(".minutes"), 
        $parentContainer = $(".booking-container"), _isMapInit = false, monthArray = [], 
        elementPosition = $parentContainer.offset();
        idx = 0, flag = 0, whenFlag = 0, whoFlag = 0, $allCheckBox = $(".who-tab"), $checkBoxLabel = $allCheckBox.find("label"), 
        $removeIcon = $(".js-close-icon"), apptNameLength = $(".apptName").length, apptSelected = 0, 
        $stylists = $(".booking-blocks .stylists"), $onlyWho = $(".who-block"), $onlyWhen = $(".when-block"), 
        $onlyWhere = $(".where-block"), $firstText = $(".when-block").find(".first");
        monthArray[0] = "October";
        monthArray[1] = "November";
        monthArray[2] = "December";
        var $allBookingContainers = $(".booking-data-container"), $whoContainer = $(".booking-data-container.who-block"), $whenContainer = $(".booking-data-container.when-block"), $checkoutContainer = $(".booking-data-container.checkout-block"), $bookingTab = $(".booking-blocks"), $mainTabs = $(".booking-blocks.where-block, .booking-blocks.when-block, .booking-blocks.who-block"), $who = $(".booking-blocks.who-block"), $when = $(".booking-blocks.when-block"), $where = $(".booking-blocks.where-block"), $whoTab = $(".who-tab"), $allFooters = $(".upper-footer,.site-footer ");
        $bookingHeader = $(".booking-header"), $minuteSelect = $(".date-wrapper").find(".minutes"), 
        $parentContainer = $(".booking-container"), _isMapInit = false, monthArray = [], 
        elementPosition = $parentContainer.offset();
        idx = 0, flag = 0, whenFlag = 0, whoFlag = 0, $allCheckBox = $(".who-tab"), $checkBoxLabel = $allCheckBox.find("label"), 
        $removeIcon = $(".js-close-icon"), apptNameLength = $(".apptName").length, apptSelected = 0, 
        $stylists = $(".booking-blocks .stylists"), $onlyWho = $(".who-block"), $onlyWhen = $(".when-block"), 
        $onlyWhere = $(".where-block"), $firstText = $(".when-block").find(".first");
        monthArray[0] = "October";
        monthArray[1] = "November";
        monthArray[2] = "December";
        if ($(window).width() > 768) {
            $bookingTab.on("click", function() {
                var className = $(this).attr("class"), singleClass = className.split(" ");
                $parentContainer.css("padding", 0);
                $bookingHeader.addClass("booking-mode-2");
                $("body").scrollTo($parentContainer, {
                    duration: 1e3
                });
                $bookingTab.removeClass("booking-active final-mode").addClass("booking-mode");
                $(this).parent().removeClass("inner-wrapper");
                scrollFix();
                if ($bookingHeader.hasClass("booking-mode-2")) {
                    $bookingHeader.on("click", function() {
                        location.reload();
                    });
                }
                $allBookingContainers.slideUp(function() {
                    $(this).removeClass("booking-active").addClass("booking-inactive");
                });
                $("." + singleClass[1]).slideDown(function() {
                    $(this).removeClass("booking-inactive").addClass("booking-active");
                });
                $firstText.text(monthArray[idx]);
                if (singleClass[1] === "where-block" && $bookingTab.hasClass("normal-mode")) {
                    $bookingTab.removeClass("normal-mode");
                    $when.add($who).addClass("booking-disabled booking-left");
                    $when.add($who).unbind("click");
                    flag = 1;
                    whereBlock(flag);
                } else if (singleClass[1] === "when-block" && $bookingTab.hasClass("normal-mode")) {
                    $bookingTab.removeClass("normal-mode");
                    flag = 2;
                    $who.addClass("second-block");
                    $when.addClass("first-block");
                    $where.addClass("third-block");
                    whenBlock(flag);
                } else if (singleClass[1] === "who-block" && $bookingTab.hasClass("normal-mode")) {
                    $bookingTab.removeClass("normal-mode");
                    $when.add($where).addClass("booking-disabled booking-left");
                    $when.add($where).unbind("click");
                    flag = 3;
                    $who.addClass("first-block");
                    $when.addClass("second-block");
                    $where.addClass("third-block");
                    if (flag === 3) {
                        $where.add($when).addClass("booking-disabled");
                    }
                    $(".regular-checkbox").on("click", function() {
                        var $parent = $(this).parent().parent(), $stylist = $(this).parent().find("input").val();
                        changeWhoHeading($parent);
                        $parent.addClass("selected");
                        checkSelectedAppts(flag);
                    });
                }
                function whereBlock(flag) {
                    if (flag === 1) {
                        $minuteSelect.find(".active").on("click", function() {
                            $("body").scrollTo(115, {
                                duration: 1e3
                            });
                            whenBlock(flag);
                            blockClick($onlyWho);
                            $(".regular-checkbox").on("click", function() {
                                var $parent = $(this).parent().parent(), $stylist = $(this).parent().find("input").val();
                                changeWhoHeading($parent);
                                $parent.addClass("selected");
                                checkSelectedAppts(flag);
                            });
                        });
                    }
                }
                function whenBlock(flag) {
                    if (flag === 2) {
                        $where.add($who).addClass("booking-disabled booking-left");
                        $where.add($who).unbind("click");
                        $minuteSelect.find(".active").on("click", function() {
                            $who.bind("click");
                            blockClick($onlyWho);
                            $who.removeClass("booking-left booking-disabled");
                            $("body").scrollTo(115, {
                                duration: 1e3
                            });
                            $(".regular-checkbox").on("click", function() {
                                var $parent = $(this).parent().parent(), $stylist = $(this).parent().find("input").val();
                                changeWhoHeading($parent);
                                $parent.addClass("selected");
                                checkSelectedAppts(flag);
                            });
                        });
                    } else if (flag === 3) {
                        $minuteSelect.find(".active").on("click", function() {
                            $when.add($where).removeClass("booking-left booking-active");
                            containerSwitch($whenContainer, $checkoutContainer);
                            $mainTabs.addClass("final-mode");
                        });
                    } else if (flag === 1) {
                        $who.removeClass("booking-disabled booking-left");
                    }
                }
                function checkSelectedAppts(flag) {
                    var $stylist = $(".who-tab"), apptSelected = $(".selected").length, stylists = "";
                    if (apptSelected === apptNameLength && flag === 3) {
                        $where.find(".address-line").text("Wheelock Place, 100AM");
                        $when.bind("click");
                        blockClick($onlyWhen);
                        $when.removeClass("booking-disabled booking-left");
                        whenBlock(flag);
                    } else if (apptSelected === apptNameLength && flag === 2) {
                        $who.removeClass("booking-active");
                        $where.find(".address-line").text("Wheelock Place, 100AM");
                        $where.removeClass("booking-left");
                        containerSwitch($whoContainer, $checkoutContainer);
                        $mainTabs.addClass("final-mode");
                    } else if (apptSelected === apptNameLength && flag === 1) {
                        containerSwitch($whoContainer, $checkoutContainer);
                        $who.removeClass("booking-active");
                        $mainTabs.addClass("final-mode");
                    }
                }
                function containerSwitch(hideBlock, showBlock) {
                    hideBlock.slideUp(function() {
                        $(this).removeClass("booking-active").addClass("booking-inactive");
                    });
                    showBlock.slideDown(function() {
                        $(this).removeClass("booking-inactive").addClass("booking-active");
                    });
                }
                function stylistSelect() {
                    $(".regular-checkbox").on("click", function() {
                        var $parent = $(this).parent().parent(), $stylist = $(this).parent().find("input").val();
                        changeWhoHeading($parent);
                        $parent.addClass("selected");
                        checkSelectedAppts(flag);
                    });
                }
                if (!_isMapInit || $(this).hasClass("booking-blocks, where-block, booking-active")) {
                    initialize();
                    _isMapInit = true;
                }
            });
        }
        function scrollFix() {
            $(window).scroll(function() {
                if ($(window).scrollTop() > elementPosition.top) {
                    $parentContainer.addClass("fix-me");
                    $allBookingContainers.css({
                        position: "relative",
                        top: 132
                    });
                    $allFooters.css({
                        position: "relative",
                        top: 132
                    });
                } else {
                    $parentContainer.removeClass("fix-me");
                    $allBookingContainers.css({
                        position: "relative",
                        top: 0
                    });
                    $allFooters.css({
                        position: "relative",
                        top: 0
                    });
                }
            });
        }
    })();
    (function() {
        var $allCheckBox = $(".who-tab"), $checkBoxLabel = $allCheckBox.find(".regular-checkbox"), $removeIcon = $(".js-close-icon"), apptNameLength = $(".apptName").length, apptSelected = 0, $stylists = $(".booking-blocks .stylists");
        if ($(window).width() > 768) {
            $checkBoxLabel.on("click", function() {
                var $parent = $(this).parent().parent(), $stylist = $(this).parent().find("input").val();
                $parent.addClass("selected");
                checkSelectedAppts();
            });
        }
        $removeIcon.on("click", function() {
            var apptName = $(this).parent().attr("class");
            apptName = apptName.replace("apptName ", "");
            $("." + apptName).remove();
            apptNameLength--;
        });
        function checkSelectedAppts() {
            var $stylist = $(".who-tab"), apptSelected = $(".selected").length, $parentContainer = $(".booking-container");
            stylists = "";
            if (apptSelected === apptNameLength) {}
            $allCheckBox.each(function() {
                if ($(this).find("input:checked").val() !== undefined) stylists += $(this).find("input:checked").val();
            });
        }
    })();
    (function() {
        var $availableDate = $(".date-block").find(".active-dates.available"), $inactiveDate = $(".date-block").find(".active-dates:not(.available)"), $thisMonth = $(".date-block").find(".active-dates"), $hourSelect = $(".date-wrapper").find(".hours"), $minuteSelect = $(".date-wrapper").find(".minutes"), $bookingBlock = $(".booking-blocks"), $whoBlock = $(".booking-blocks.who-block");
        if ($(window).width() > 768) {
            $availableDate.find("strong").text("available");
            $inactiveDate.removeClass("active-dates").addClass("inactive-dates");
            $thisMonth.on("click", function() {
                $thisMonth.removeClass("active-block");
                $(this).toggleClass("active-block");
            });
            $hourSelect.find("li.active").on("click", function() {
                $hourSelect.animate({
                    left: "-105%"
                });
                $minuteSelect.animate({
                    right: "0"
                });
            });
            $minuteSelect.find(".back-to-hours").on("click", function() {
                $hourSelect.animate({
                    left: "0"
                });
                $minuteSelect.animate({
                    right: "-100%"
                });
            });
        }
    })();
    (function() {
        var $dateBlock = $(".date-block"), $dayBlock = $(".day-block"), $timeBlock = $(".time-wrapper"), $bookingHeader = $(".when-block.booking-data-container"), $bookingLine = $(".when-block.booking-data-container p"), bookingLineHeight = parseInt($bookingLine.css("margin-top")) + parseInt($bookingLine.css("margin-bottom")) + $bookingLine.height(), bookingHeaderHeight = $bookingHeader.find("h3").height(), dateBlockHeight = $dayBlock.height() + parseInt($dayBlock.css("margin-top")) + parseInt($dayBlock.css("margin-bottom")) + parseInt($dateBlock.css("margin-top"));
        $dateBlock.on("click", ".active-dates", function() {
            $dateBlock.find("li").removeClass("slide-block-down");
            dateBlockNumber = $(this).index();
            rowNumber = Math.ceil((dateBlockNumber + 1) / 7);
            if ($(window).width() > 992) {
                dateBlockLength = 135;
                $timeBlock.slideDown().css({
                    top: 183 + rowNumber * dateBlockLength
                });
            } else if ($(window).width() < 993 && $(window).width() > 768) {
                dateBlockLength = 135;
                $timeBlock.slideDown().css({
                    top: 165 + rowNumber * dateBlockLength
                });
            }
            nextElement = rowNumber * 7 + 1;
            for (var i = nextElement, d1 = $(".date-block li").length; i <= d1; i++) {
                $dateBlock.find("li:nth-of-type(" + i + ")").addClass("slide-block-down");
            }
            $bookingHeader.addClass("date-height-increase");
        });
    })();
    var closeModal = $(".close-modal"), blurModal = $(".modal-blur");
    closeModal.on("click", function() {
        containerModal = $(this).parent();
        containerModal.slideUp();
        containerModal.prev().hide();
    });
    blurModal.on("click", function() {
        $(this).next().slideUp();
        $(this).hide();
    });
    (function() {
        var $inputContainer = $(".register-text.input"), $registerButton = $(".btn-register.button"), $updateButton = $(".btn-register.update"), $payButton = $(".pay"), $containerOverlay = $(".load-overlay"), flag = 0, checkValid, empty;
        function buttonValidation(text) {
            $inputContainer.each(function() {
                var $this = $(this), errorString = $this.attr("data-message");
                $this.find("span.error-span").next().remove();
                var pwd = $(this).find("input").attr("id");
            	if (text == "update" && (pwd == "inputPassword" || pwd == "inputConfirmPassword")){
            		if ($("#inputPassword").val().length > 0 || $("#inputConfirmPassword").val().length > 0){
            			var emptyInput = $this.find("input");
                        if (emptyInput.val().length < 1) {
                            emptyInput.addClass("invalid-input");
                            $this.find("span.error-span").after('<p class="error-span error-message invalid">' + errorString + "</p>");
                        }
            		}
            	}else if ($this.find("input").length) {
                    var emptyInput = $this.find("input");
                    if (emptyInput.val().length < 1) {
                        emptyInput.addClass("invalid-input");
                        $this.find("span.error-span").after('<p class="error-span error-message invalid">' + errorString + "</p>");
                    }
                } else {
                    var noneSelected = $this.find("select");
                    if (noneSelected.val() === null) {
                        noneSelected.prev().addClass("invalid-input");
                        $this.find("span.error-span").after('<p class="error-span error-message invalid">' + errorString + "</p>");
                    }
                }
            });
            if ($(".invalid-input").length) {
                scrollAnchor = $(".invalid-input").offset().top - 40;
                $("body").scrollTo(scrollAnchor, {
                    duration: 1e3
                });
            }
            $inputContainer.each(function() {
            	console.log("text=="+text);
            	var pwd = $(this).find("input").attr("id");
            	if (text == "update" && (pwd == "inputPassword" || pwd == "inputConfirmPassword")){
            		if ($("#inputPassword").val().length == 0 && $("#inputConfirmPassword").val().length == 0){
            			flag = 1;
            		}else{
            			checkValid = $(this).find("input").hasClass("invalid-input");
                        empty = $(this).find("input").val().length;
            		}
            	}else if ($(this).find("input").length) {
                    checkValid = $(this).find("input").hasClass("invalid-input");
                    empty = $(this).find("input").val().length;
                } else {
                    checkValid = $(this).find("select").prev().hasClass("invalid-input");
                    empty = $(this).find("select").val();
                }
                if (checkValid === true || empty < 1) {
                    flag = 0;
                    return false;
                } else {
                    flag = 1;
                }
            });
            if (flag === 1) {
				console.log("text=="+text);
                if (text === "registration") {
                    //$containerOverlay.load("../overlays/registration-success.html");
                	openConfirmationPage();
					//window.location = "../overlays/registration-success.html";
                } else if (text === "update") {
                	updateCall();
					//window.location = "../../overlays/update-page.html";
                    //$containerOverlay.load("../../overlays/update-page.html");
                } else if (text === "payment") {
                	// alert("I am here ..");
                	submitForm();
					//window.location = "../overlays/confirmation-booking-payment.html";
                    //$containerOverlay.load("../overlays/confirmation-booking-payment.html");
                }
            }
        }
        $registerButton.on("click", function() {
            text = "registration";
            buttonValidation(text);
        });
        $updateButton.on("click", function() {
            text = "update";
            buttonValidation(text);
        });
        $payButton.on("click", function() {
            text = "payment";
            buttonValidation(text);
        });
    })();
    (function() {
        var firstName = $("#inputFirstname"), lastName = $("#inputLastname"), fullName = $("#inputFirstname, #inputLastname"), phoneNumber = $("#inputMobile"), birthDate = $("#inputBirthdate"), emailName = $("#inputEmail"), title = $(".register-text").find(".title-select"), gender = $(".register-text").find(".gender-select"), confirmEmail = $("#inputConfirmEmail"), password = $("#inputPassword"), confirmPassword = $("#inputConfirmPassword"), mailingAddress = $(".mailing"), billingAddress = $(".billing");
        billingAddress.find(".check").on("click", function() {
            if (this.checked) {
                mailingAddress.slideUp();
            } else {
                mailingAddress.slideDown();
            }
        });
        title.blur(function() {
            var errorMsg = "Please select.", errorNumber = 1, titleText = $(this).prev();
            displayError = $(this).parent().parent().next();
            console.log(titleText.text());
            if (titleText.text() === "Mr" || titleText.text() === "Mrs" || titleText.text() === "Miss") is_string = true; else is_string = false;
            checkNameValidity(displayError, is_string, errorMsg, titleText, errorNumber);
        });
        gender.blur(function() {
            var errorMsg = "Please select gender. We are interested, because we would like to serve you relevant information.", errorNumber = 1, genderText = $(this).prev();
            displayError = $(this).parent().parent().next();
            if (genderText.text() === "Male" || genderText.text() === "Female") is_string = true; else is_string = false;
            checkNameValidity(displayError, is_string, errorMsg, genderText, errorNumber);
        });
        lastName.blur(function() {
            var errorMsg = "Sorry, we missed your name.", errorNumber = 1, displayError = $(this).parent().parent().find("span"), fullNameString = $(this).val() + $(this).siblings("input[type=text]").val(), checkString = /^[a-zA-Z]*$/, is_string = checkString.test(fullNameString);
            if (is_string) {
                if (lastName.val().length > 0 && firstName.val().length > 0) {
                    is_string = true;
                } else {
                    is_string = false;
                }
            } else {
                is_string = false;
            }
            if (lastName.val().length > 0 || firstName.val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, fullName, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                fullName.removeClass("invalid-input");
            }
        });
        password.blur(function() {
            var errorMsg = "Are you sure your password has at least one capital letter and one digit?", errorNumber = 1, displayError = $(this).next(), checkPassword = /^(?=.*\d)[0-9a-zA-Z]{6,}$/, is_string = checkPassword.test($(this).val());
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, password, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                password.removeClass("invalid-input");
            }
            if (is_string) {
                textboxDisabled($(this), confirmPassword, password);
                password.removeClass("invalid-input");
            }
        });
        confirmPassword.blur(function() {
            var errorMsg = "Doh, the passwords don't seem to match. ", errorNumber = 1, is_string = false, displayError = $(this).next("span");
            if ($(this).val() === password.val()) {
                is_string = true;
            } else {
                is_string = false;
            }
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, confirmPassword, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                confirmPassword.removeClass("invalid-input");
            }
        });
        phoneNumber.blur(function() {
            var errorMsg = "Are you sure you entered your 8 digits? ", errorNumber = 1;
            displayError = $(this).next(), checkString = /^\d{8}$/, is_string = checkString.test($(this).val());
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, phoneNumber, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                phoneNumber.removeClass("invalid-input");
            }
        });
        birthDate.blur(function() {
            var errorMsg = "Sorry, should be in DD/MM/YYYY", displayError = $(this).next("span"), errorNumber = 1, checkString = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/, is_string = checkString.test($(this).val());
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, birthDate, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                birthDate.removeClass("invalid-input");
            }
        });
        emailName.blur(function() {
            var errorMsg = "Do we have your email?", errorNumber = 1;
            displayError = $(this).next(), checkEmail = /^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/, 
            is_string = checkEmail.test($(this).val());
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, emailName, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                emailName.removeClass("invalid-input");
            }
            if (is_string) {
                textboxDisabled($(this), confirmEmail, emailName);
            }
        });
        confirmEmail.blur(function() {
            var errorMsg = "Are you sure they match with the one above? ", errorNumber = 1, is_string = false, displayError = $(this).next("span");
            if ($(this).val() === emailName.val()) {
                is_string = true;
            } else {
                is_string = false;
            }
            if ($(this).val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, confirmEmail, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                confirmEmail.removeClass("invalid-input");
            }
        });
        function checkNameValidity(displayError, is_true, errorString, inputBox, errorNumber) {
            console.log("hello world " + is_true);
            if (is_true) {
                displayError.removeClass("valid invalid").text("").addClass("valid").next().remove();
                inputBox.removeClass("invalid-input");
                if (errorNumber === 1) displayError.removeClass("error-message");
            } else {
                displayError.removeClass("valid invalid error-message").addClass("invalid").next().remove();
                inputBox.addClass("invalid-input");
                if (errorNumber === 1) displayError.after('<p class="error-span error-message invalid">' + errorString + "</p>");
            }
        }
        function textboxDisabled(mainElement, confirmElement) {
            if (mainElement.val().length > 0) {
                confirmElement.prop("disabled", false);
            } else {
                confirmElement.prop("disabled", true);
            }
        }
    })();
    (function() {
        var $inputContainer = $(".text-wrap"), $mainLogin = $(".btn-login.main-login"), $forgotButton = $(".btn-login.forgot-password"), $orderButton = $(".btn-login.order-login"), $newCustButton = $(".btn-login.new-cust"), $otpButton = $(".btn-login.otp-button"), $setButton = $(".btn-login.set-button"), $containerOverlay = $(".load-overlay"), checkValid, empty, flag = 0;
        function overlayButtonValidation(text) {
            $inputContainer.each(function() {
                emptyInput = $(this).find("input");
                errorString = $(this).attr("data-message");
                if (emptyInput.val().length < 1) {
                    emptyInput.next().remove();
                    emptyInput.addClass("invalid-input").after('<em class="erMsg">' + errorString + "</p>");
                }
            });
            $inputContainer.each(function() {
                checkValid = $(this).find("input").hasClass("invalid-input");
                empty = $(this).find("input").val().length;
                if (checkValid === true || empty < 1) {
                    flag = 0;
                    return false;
                } else {
                    flag = 1;
                }
            });
            if (flag === 1) {				
				console.log("text=="+text);				
                if (text === "main-login") {	
                	authenticateUser();
                    //window.location = "categories/index.html";
                } else if (text === "forgot-password") {
                	forgotPasswordUser();
                    //window.location = "/overlays/email-sent.php";
                } else if (text === "order-login") {
                    window.location = "/profile/profile-landing/";
                } else if (text === "new-customer") {
                	regNewCustomer();
                    //window.location = "../overlays/otp-page.html";
                } else if (text === "otp") {
                	call();
                } else if (text === "set-password") {
                    window.location = "/overlays/password-reset-confirm.php";
                }
            } else {

            }
        }
        $mainLogin.on("click", function() {
            text = "main-login";
            overlayButtonValidation(text);
        });
        $forgotButton.on("click", function() {
            text = "forgot-password";
            overlayButtonValidation(text);
        });
        $orderButton.on("click", function() {
            text = "order-login";
            overlayButtonValidation(text);
        });
        $newCustButton.on("click", function() {
            text = "new-customer";
            overlayButtonValidation(text);
        });
        $otpButton.on("click", function() {
            text = "otp";
            overlayButtonValidation(text);
        });
        $setButton.on("click", function() {
            text = "set-password";
            overlayButtonValidation(text);
        });
    })();
    (function() {
        loginEmail = $("#loginEmail"), forgottenEmail = $("#forgottenPasswordMail"), loginPassword = $("#loginPassword, #confirmNewPassword"), 
        loginNewPassword = $("#newPassword"), confirmLoginPassword = $("#confirmNewPassword"), 
        loginMobileNumber = $("#mobileNumber"), otpNumber = $("#otpNumber");
        loginEmail.blur(function() {
            var errorMsg = 'We cannot find your email in our database. If you are new to our services, please <a href="/register/">register</a>.', errorNumber = 1, inputBox = $(this);
            checkEmail = /^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/, is_string = checkEmail.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        forgottenEmail.blur(function() {
            var errorMsg = "Email seems to have wrong format, please try it again.", errorNumber = 1, inputBox = $(this);
            checkEmail = /^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/, is_string = checkEmail.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        loginPassword.blur(function() {
            var errorMsg = 'Oops, password is wrong. Did you forget your password? We can reset it <a href="/overlays/newpassword.php">here</a>.', errorNumber = 1, inputBox = $(this);
            checkPassword = /^(?=.*\d)[0-9a-zA-Z]{6,}$/, is_string = checkPassword.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        loginNewPassword.blur(function() {
            var errorMsg = "This does not seem to be the correct format. Do we have one capital letter and one number?", errorNumber = 1, inputBox = $(this);
            checkPassword = /^(?=.*\d)[0-9a-zA-Z]{6,}$/, is_string = checkPassword.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        loginMobileNumber.blur(function() {
            var errorMsg = "The format seems to be wrong, can you double check the number has 8 digits.", errorNumber = 1, inputBox = $(this);
            checkPassword = /^\d{8}$/, is_string = checkPassword.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        otpNumber.blur(function() {
            var inputBox = $(this);
            checkPassword = /^\d{6}$/, is_string = checkPassword.test($(this).val());
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        confirmLoginPassword.blur(function() {
            var inputBox = $(this);
            errorMsg = "The passwords do not seem to match. Try again please.", errorNumber = 1, 
            is_string = false;
            inputBox.next("em").remove();
            if ($(this).val() === loginNewPassword.val()) {
                is_string = true;
            } else {
                is_string = false;
            }
            if ($(this).val().length > 0) {
                checkeOverlayValidity(is_string, inputBox, errorNumber, errorMsg);
            } else {
                inputBox.removeClass("invalid-input").next(".erMsg").remove();
            }
        });
        function checkeOverlayValidity(is_true, inputBox, errorNumber, errorMsg) {
            inputBox.next(".erMsg").remove();
            if (is_true) {
                inputBox.removeClass("invalid-input");
            } else {
                inputBox.addClass("invalid-input");
                if (errorNumber === 1) {
                    inputBox.after('<em class="erMsg">' + errorMsg + "</em>");
                }
            }
        }
    })();
    (function() {
        var cardHolderName = $("#cardHolderName"), cardNumber = $(".cardNumber"), expiryDate = $(".expiryDate"), cvv = $("#cvv");
        cardHolderName.blur(function() {
            var errorMsg = " Please enter valid card holder name.", errorNumber = 1, displayError = $(this).next("span"), cardHolderNameString = $(this).val(), checkString = /^[a-zA-Z]*$/, is_string = checkString.test(cardHolderNameString);
            if (is_string) {
                if (cardHolderName.val().length > 0) {
                    is_string = true;
                } else {
                    is_string = false;
                }
            } else {
                is_string = false;
            }
            if (cardHolderName.val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, cardHolderName, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                cardHolderName.removeClass("invalid-input");
            }
        });
        cardNumber.blur(function() {
            var errorMsg = "Please enter the 16 digits on your card.", errorNumber = 1, displayError = $(this).next(), checkString = /\d{12,}/, is_string = checkString.test($(this).val());
            cardNumber.removeClass("visa-electro discover visa mastercard maestro");
            if (cardNumber.val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, cardNumber, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                cardNumber.removeClass("invalid-input");
            }
        });
        expiryDate.blur(function() {
            var errorMsg, displayError = $(this).next("span"), errorNumber = 1, checkString = /^(\d{1,2})$/, is_string = checkString.test($(this).val()), thisInd = $(this).index();
            if (thisInd == 1) errorMsg = "Are you sure it is in MM format?"; else errorMsg = "Are you sure it is in YY format?";
            if (expiryDate.val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, expiryDate, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                expiryDate.removeClass("invalid-input");
            }
        });
        cvv.blur(function() {
            var errorMsg = "", errorNumber = 1, displayError = $(this).next().next(), checkString = /\d{3}/, is_string = checkString.test($(this).val());
            if (cvv.val().length > 0) {
                checkNameValidity(displayError, is_string, errorMsg, cvv, errorNumber);
            } else {
                displayError.removeClass("valid invalid").next().remove();
                cvv.removeClass("invalid-input");
            }
        });
        function checkNameValidity(displayError, is_string, errorString, inputBox, errorNumber) {
            if (is_string) {
                displayError.parent().find(".error-span").removeClass("valid invalid invalid").text("");
                inputBox.removeClass("invalid-input");
                if (errorNumber === 1) displayError.removeClass("error-message");
                cardType(inputBox);
            } else {
                displayError.parent().find(".error-span").removeClass("valid invalid invalid").text("");
                inputBox.addClass("invalid-input");
                if (errorNumber === 1) {
                    displayError.parent().find(".error-span").addClass("error-message invalid").text(errorString);
                }
            }
        }
        var cards = [];
        cards.push({
            name: "visa-electron",
            checkText: /^(4026|417500|4508|4844|491(3|7))/
        });
        cards.push({
            name: "discover",
            checkText: /^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/
        });
        cards.push({
            name: "visa",
            checkText: /^4/
        });
        cards.push({
            name: "mastercard",
            checkText: /^5[1-5]/
        });
        cards.push({
            name: "maestro",
            checkText: /^(5018|5020|5038|6304|6759|676[1-3])/
        });
        function cardType(inputBox) {
            var checkValue = inputBox.val();
            for (var i = 0; i < cards.length; i++) {
                validCard = cards[i].checkText.test(checkValue);
                if (validCard) {
                    inputBox.addClass(cards[i].name);
                    break;
                }
            }
        }
        function textboxDisabled(mainElement, confirmElement) {
            if (mainElement.val().length > 0) confirmElement.prop("disabled", false); else confirmElement.prop("disabled", true);
        }
    })();
    (function() {
        var $clonePromoRow, userEnteredValue = 0, originalPrice, addVoucher = $(".pricing"), voucherSelect = $(".redemption-select"), voucherValue = $(".redemption-select option:selected").val(), titleCode = $(".promo").find(".overlay").text(), v1 = '<li class="checkout-item"><div class="info product">', v2 = '</div><div class="info qty">', v3 = '</div><div class="info price"><p class="discount-price">-$', v4 = '</p></div><div class="info close-info"> <span class="close">close-overlay</span> </div> </li>', $finalPrice = $(".final-price"), itemOrignalPrices = [];
        updateGrandTotal();
        $(".redemption-select").on("change", function() {
            voucherValue = $(this).val();
            titleCode = $(".promo").find(".overlay").text();
        });
        addVoucher.find(".checkout-item").each(function() {
            var1 = $(this).find(".item-price").text();
            itemOrignalPrices.push(var1);
        });
        $(".deduce-dropdown").on("change", function() {
            value = $(this).val();
            dataParent = $(this).parent().parent().parent().parent();
            parentNumber = dataParent.parent().index();
            replacePrice = dataParent.next().next().find(".item-price");
            if (value === "package" || value === "credit") {
                replacePrice.text("$0.00");
            } else {
                replacePrice.text(itemOrignalPrices[parentNumber]);
            }
            updateGrandTotal();
        });
        $(".addit").on("click", function(e) {
            e.preventDefault();
            $(this).parent().hide();
            $(".promo").show();
        });
        $(".apply").on("click", function(e) {
            e.preventDefault();
            userEnteredValue = $(this).parent().prev().find('input[type="text"]');
            if (parseInt(userEnteredValue.val()) === 123456) {
                addVoucher.append(v1 + titleCode + v2 + "1x" + v3 + voucherValue + v4);
                updateGrandTotal();
            } else {
                userEnteredValue.val("");
            }
        });
        addVoucher.on("click", ".close", function(e) {
            e.preventDefault();
            $(this).parent().parent().remove();
            updateGrandTotal();
        });
        function updateGrandTotal() {
            $input = $(".pricing").find(".checkout-item"), grandTotal = 0, totalDiscount = 0, 
            total = 0;
            $input.each(function() {
                var itemPrice = $(this).find(".item-price").text(), discountPrice = $(this).find(".discount-price").text();
                itemPrice = Number(itemPrice.replace("$", ""));
                discountPrice = Number(discountPrice.replace("-$", ""));
                totalDiscount += discountPrice;
                grandTotal += itemPrice;
            });
            total = grandTotal - totalDiscount;
            if (total <= 0) {
                total = grandTotal;
                addVoucher.find(".checkout-item:last").remove();
                $(".apply").css("pointer-events", "none");
            }
            $finalPrice.find(".total-price").text("$" + parseFloat(total, 10).toFixed(2));
        }
    })();
    (function() {
        var checkoutInd = 0, $checkoutContainerHeader = $(".checkout-container h1");
        $checkoutContainerHeader.on("click", function() {
            var $this = $(this), scrollAnchor = $this.get($this.index()), checkoutInd = $this.parent().index();
            $this.siblings(".summary").hide();
            $this.next().slideToggle();
            $this.parent().siblings("section").find(".entry").slideUp();
            $this.parent().prev().find(".summary").show(function() {
                $("body").scrollTo(scrollAnchor, {
                    duration: 1e3
                });
            });
        });
        $(".continue").on("click", function(evt) {
        	processPayment();
        	//alert("Continue clicked ...");
        	/*
            evt.preventDefault();
            var $this = $(this);
            $this.parent().slideUp();
            $this.parent().parent().next().find(".entry").slideDown();
            $this.parent().parent().find(".summary").slideDown(function() {
                checkoutInd++;
                scrollAnchor = $checkoutContainerHeader.get(checkoutInd);
                $("body").scrollTo(scrollAnchor, {
                    duration: 1e3
                });
            });
            */
        });
    })();
    (function() {
        var $registerHeading = $(".page-container.register-page h1"), $registerForm = $(".page-container.register-page").find("#register-form");
        $registerMobile = $("#inputMobile");
        $(init);
        function init() {
            //$.getJSON("../../assets/seg/js/profile-data.json", processResult);
        }
        function processResult(data) {
            for (var i in data.users) {
                $registerHeading.append(data.users[i].firstName + "!");
                $registerForm.find("#inputFirstname").val(data.users[i].firstName);
                $registerForm.find("#inputLastname").val(data.users[i].lastName);
                $registerForm.find(".title-select").prev().text(data.users[i].title);
                $registerForm.find(".gender-select").prev().text(data.users[i].gender);
                $registerForm.find(".notification-select").prev().text("Via " + data.users[i].notification);
                $registerForm.find("#inputBirthdate").val(data.users[i].birthDate);
                $registerForm.find("#inputMobile").val(data.users[i].mobileNumber);
                $registerMobile.val(data.users[i].mobileNumber);
                $registerForm.find("#inputEmail").val(data.users[i].email);
                $registerForm.find("#inputPassword").val(data.users[i].password);
                if (data.users[i].gender === "female") {
                    $registerForm.find(".gender-select > option:eq(2)").attr("selected", true);
                } else {
                    $registerForm.find(".gender-select > option:eq(1)").attr("selected", true);
                }
                if (data.users[i].title === "mr") {
                    $registerForm.find(".title-select > option:eq(1)").attr("selected", true);
                } else if (data.users[i].title === "mrs") {
                    $registerForm.find(".title-select > option:eq(2)").attr("selected", true);
                } else {
                    $registerForm.find(".title-select > option:eq(3)").attr("selected", true);
                }
            }
            $(".account-bar li:eq(0) > a").html("Hello " + data.users[i].firstName);
        }
    })();
    (function() {
        var $registerForm = $(".page-container.payment-page").find("#payment-form");
        $(init);
        function init() {
            $.getJSON("../../assets/seg/js/profile-data.json", processResult);
        }
        function processResult(data) {
            for (var i in data.users) {
                $registerForm.find("#inputFirstname").val(data.users[i].firstName);
                $registerForm.find("#inputLastname").val(data.users[i].lastName);
                $registerForm.find("#inputMobile").val(data.users[i].mobileNumber);
                $registerForm.find("#inputEmail").val(data.users[i].email);
                if (data.users[i].gender === "female") {
                    $registerForm.find("#female").prop("checked", true);
                } else {
                    $registerForm.find("#male").prop("checked", true);
                }
            }
            $(".account-bar li:eq(0) > a").html("Hello " + data.users[i].firstName);
        }
    })();
    (function() {
        $backstretch = $(".bg-image");
        if ($backstretch.length) {
            $backstretch.each(function() {
                $this = $(this), _img = $this.data("image");
                $this.backstretch(_img).backstretch("resize");
            });
        }
    })();
    var mapCanvas = $("#map-canvas");
    if (mapCanvas.length) {
        var zoomValue, windowSize = $(window).width();
        if (windowSize > 992) zoomValue = 14; else zoomValue = 13;
        function initialize() {
            var mapOptions = {
                center: {
                    lat: 1.3096,
                    lng: 103.8205
                },
                zoom: zoomValue,
                scaleControl: false,
                disableDefaultUI: true,
                scrollwheel: false,
                zoomControl: true,
                zoomControlOptions: {
                    style: google.maps.ZoomControlStyle.SMALL
                }
            };
            var map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);
            setMarkers(map, shops);
        }
        var shops = [ {
            title: "Address 1",
            lat: 1.3267,
            lng: 103.8213,
            line: "Beauty Emporium Dempsey"
        }, {
            title: "Address 2",
            lat: 1.3182,
            lng: 103.8302,
            line: "Wheelock Place, 100AM"
        }, {
            title: "Address 3",
            lat: 1.3035,
            lng: 103.8509,
            line: "Mandarin Gallery"
        }, {
            title: "Address 4",
            lat: 1.3078,
            lng: 103.7922,
            line: "Raffles City Street Level"
        } ];
        //var markers = new Array(), markerImage = "/images/image-marker.png", markerImageHover = "/images/image-marker-hover.png", latlngbounds = new google.maps.LatLngBounds(), $who = $(".booking-blocks.who-block"), $when = $(".booking-blocks.when-block"), $where = $(".booking-blocks.where-block"), $onlyWho = $(".who-block"), $onlyWhen = $(".when-block"), $onlyWhere = $(".where-block"), flag = 1, whenFlag = 1, showAddress = $(".map-address").find(".address-line");
        function setMarkers(map, locations) {
            for (var i = 0; i < locations.length; i++) {
                var data = locations[i], latLng = new google.maps.LatLng(data.lat, data.lng), AddressLine = data.line, Map = map;
                var marker = new google.maps.Marker({
                    position: latLng,
                    map: Map,
                    icon: markerImage,
                    htmltext: AddressLine
                });
                var infowindow = new InfoBox({
                    content: '<a class="scrollFix">' + AddressLine + "</a>",
                    disableAutoPan: false,
                    pixelOffset: new google.maps.Size(40, -35),
                    zIndex: null,
                    infoBoxClearance: new google.maps.Size(1, 1)
                });
                infowindow.open(Map, marker);
                latlngbounds.extend(latLng);
                var mapAddress = new Array();
                var showAddress = $(".map-address").find(".address-line"), mapAddress = new Array();
                $parentContainer = $(".booking-container");
                google.maps.event.addListener(marker, "click", function() {
                    for (var i = 0; i < markers.length; i++) {
                        markers[i].setIcon(markerImage);
                    }
                    this.setIcon(markerImageHover);
                    showAddress.text(this.htmltext);
                    $("body").scrollTo($parentContainer, {
                        duration: 1e3
                    });
                    $when.bind("click");
                    blockClick($onlyWhen);
                    $when.removeClass("booking-disabled booking-left");
                });
                markers.push(marker);
            }
            Map.fitBounds(latlngbounds);
        }
        var $dropDownOutlets = $(".where-block select");
       /* $dropDownOutlets.on("change", function() {
            showAddress.text($(this).find("option:selected").text());
            $when.bind("click");
            blockClick($onlyWhen);
        });*/
    }
    var $resetButton = $(".who-tab .reset-stylist");
    (function() {
        var $radioButton = $(".who-block .regular-checkbox"), $empty = $(".who-tab");
        $empty.on("click", ".reset-stylist", function(event) {
            event.preventDefault();
            $radioButton.prop("checked", false);
            changeWhoHeadingPrev($empty);
            $(".stylist1, .stylist2").text("");
            $empty.removeClass("selected");
        });
    })();
    function changeWhoHeading(parentElement) {
        changeBlock = parentElement.siblings(".who-tab");
        allWho = $(".who-tab");
        allWho.find("h4 > reset-stylist").remove();
        if (!changeBlock.hasClass("selected")) {
            changeBlock.find("h4").text(changeBlock.attr("data-message-two"));
            changeBlock.find("h4").append('<a href="#" class="reset-stylist"> reset therapist / stylist</a>');
        }
    }
    function changeWhoHeadingPrev(parentElement) {
        parentElement.each(function() {
            allWho = $(".who-tab");
            $(this).find("h4").text($(this).attr("data-message-one"));
            allWho.find("h4 > reset-stylist").remove();
        });
    }
    $(function() {
        $(".timer-div > .timer").countdowntimer({
            minutes: 5,
            seconds: 0,
            size: "lg"
        });
    });
    function blockClick(block) {
        var $allBookingContainers = $(".booking-data-container"), $whoContainer = $(".booking-data-container.who-block"), $whenContainer = $(".booking-data-container.when-block"), $checkoutContainer = $(".booking-data-container.checkout-block"), $bookingTab = $(".booking-blocks"), $mainTabs = $(".booking-blocks.where-block, .booking-blocks.when-block, .booking-blocks.who-block"), $who = $(".booking-blocks.who-block"), $when = $(".booking-blocks.when-block"), $where = $(".booking-blocks.where-block"), $whoTab = $(".who-tab");
        $mainTabs.removeClass("booking-active");
        $allBookingContainers.slideUp(function() {
            $(this).removeClass("booking-active").addClass("booking-inactive");
        });
        block.slideDown(function() {
            $(this).removeClass("booking-inactive").addClass("booking-active");
        });
    }
})(jQuery);