var gURL="";
var deviceId = encrypt(checkNull(sessionStorage.getItem("deviceid")));
var env = "DEV";
var encFlag = true;
var clientVersion = "4.0";
$(document).ready(function() {		

});

function alertDismissedClosed(){
     if(device.platform.toUpperCase() === 'ANDROID'){
         $(location).attr("href", "https://play.google.com/store/apps/details?id=com.project.spa.seg&hl=en");
     }else if (device.platform.toUpperCase() === 'IOS') {
         window.open("https://itunes.apple.com/us/app/apple-store/id1005490568?ls=1&mt=8");
     }
}

//	SOAP call for authorized user.
function authenticateUser(){

   if (deviceId == "")
		deviceId = encrypt("1234567890");
	
	if (devicePlatform == "")
		devicePlatform = "iOS";

	var clientVerWithOS = devicePlatform + "###" + clientVersion;
	var email = encrypt(document.getElementById("loginEmail").value);
	var pass = encrypt(document.getElementById("loginPassword").value);
	sessionStorage.setItem("customerEmailID", document.getElementById("loginEmail").value);
	
	var str = '{AuthCredentials: {"email":"'+email+'","pass":"'+pass+'","deviceId":"'+getSessionID()+'","clientVersion":"'+clientVerWithOS+'"}}';
	log("AuthCredentials Object: ["+str+"]");
	var data = eval("("+str+")");

    var search = {}
    search["email"] = document.getElementById("loginEmail").value;
	search["pass"] = document.getElementById("loginPassword").value;
	search["deviceId"] = getSessionID();
    search["clientVersion"] = clientVerWithOS;
   
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/search",
	    data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
          var str = data.toString();
          log("AuthenticateUser Response: "+str);
			var errIdx = str.indexOf("ERROR:");
			if (errIdx >= 0){
		       alert("ERROR");
			}else{
	            var obj = eval ("(" + str + ")"); 
				log("Email ID: ["+obj.cusLoginEmailId+"]");
				var auth = obj.status;
				var flag = true;
				
				if (flag){
					
					sessionStorage.setItem("cusId", obj.cusId);
				    sessionStorage.setItem("cusSegmentId", obj.cusDSegmentCatId);
				    sessionStorage.setItem("cusLoginEmailId", obj.cusLoginEmailId);
				    sessionStorage.setItem("cusFirstName", obj.cusFirstName);
				    sessionStorage.setItem("cusLastName", obj.cusLastName);
				    sessionStorage.setItem("custFullName", obj.cusFirstName+" "+obj.cusLastName);
				    sessionStorage.setItem("cusMobileNumber", obj.cusMobileNumber);
	                getUserDet();
			      
				}else{
					
				}
			}

        },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            
            console.log("ERROR : ", e);
            
        }
    });

}

function getUserDet(){
    
	var cusId = sessionStorage.getItem("cusId");
	var cusSegmentId = sessionStorage.getItem("cusSegmentId");
	var cusLoginEmailId = sessionStorage.getItem("cusLoginEmailId");
	var cusFirstName = sessionStorage.getItem("cusFirstName");
	var cusLastName = sessionStorage.getItem("cusLastName");
	var custFullName = sessionStorage.getItem("custFullName");
	var cusMobileNumber = sessionStorage.getItem("cusMobileNumber");
    var search = {}
    search["cusId"] = cusId;
	search["pass"] = cusSegmentId;
	search["deviceId"] = cusLoginEmailId;
    search["clientVersion"] = cusFirstName;
  
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/userdet",
        data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
          var str = data.toString();
          log("getUserDet Response: "+str);
			
			var errIdx = str.indexOf("ERROR:");
			if (errIdx >= 0){
		       alert("ERROR");
			}else{
	            var obj = eval ("(" + str + ")"); 
				var stmtLst = obj.stmtLst;
				log("Email ID: ["+stmtLst.length+"]");
				var flag = true;
				
				if (stmtLst.length > 0){

				 for(var i=0;i<stmtLst.length;i++) {
					 log("getUserDet Response: "+stmtLst[i].productId);
 					 location.href="js/index_listing.html";
				 
				}
				}else{
					
				}
			}

        },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            
            console.log("ERROR : ", e);
            
        }
    });

}

function showUserStmt(){
    var search = {}
    search["email"] = "as@gmail.com";
  
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "/api/showstmt",
	    data: JSON.stringify(search),
        dataType: 'json',
        cache: false,
        timeout: 600000,
        success: function (data) {
        
          log("AuthenticateUser Response: ");
	    },
        error: function (e) {

            var json = "<h4>Ajax Response</h4><pre>"
                + e.responseText + "</pre>";
            
            console.log("ERROR : ", e);
            
        }
    });

}
function buildStatementInnerHTML(){
	var divCategoryName = "";
	var strProductDtls = "";
	var alreadySelected = "";
	var divStmtContainerList="";
	var monthName="";
	for(var i=0; i<2;i++){	
		divCategoryName = "";
		strTreatmentDtls = "";
		if(i==0)
		{
		divCategoryName += "<div class=\"list-header active\"><h3>Monthly Statement </h3><div class=\"expand\">expand symbol</div></div>";
		 monthName="January Month";
		}
		else
		{
		 monthName="February Month";
		}
	
		for(var j=0; j<3;j++){			
			if(i == 0){
			
			 if(j==0)
			 {
			   var stmtType="Casa Statement";
			 }else if(j==1)
			 {
			    var stmtType="ECS Statement";
			 }else if(j==2)
			 {
			    var stmtType="HYA Statement";
			 }

				var fbStr = "onClick=\"shareOnSocialMedia('FB', )\"";
				var twStr = "onClick=\"shareOnSocialMedia('TW', )\"";	
				var emailStr = "onClick=\"shareOnSocialMedia('EMAIL', '', )\"";
				var shareAsDiv = "<div class=\"share-container\" style=\"display:none\"><span class=\"share clearfix\" style=\"position: inherit;\"><em>Share via</em><a href=\"#\" "+twStr+"><img src=\"../../images/sprites-general.png\" class=\"tw\" alt=\"tw-share\">twitter</a><a href=\"#\" "+fbStr+"><img src=\"../../images/sprites-general.png\" class=\"fb\" alt=\"fb-share\">facebook</a><!-- a href=\"#\" "+emailStr+"><img src=\"../../images/sprites-general.png\" class=\"mail\" alt=\"mail-share\">mail</a --></span></div>";
				strProductDtls +="<section class=\"clearfix\" style=\"display: block;\" ><h4>"+stmtType+"<em style=\"padding-top:10px;\">"+monthName+"</em> "+
					"<span class=\"cart service book\">";
				strProductDtls +="<div><p style=\"text-align:left;margin-bottom:0px;\">UOB</p></div>";
				strProductDtls +=	"<a href=\"#\" onclick=\"downloadPdf()\" class=\"btn-normal item-added\">"+
										"<img src=\"../../images/sprites-general.png\" class=\"desktop-element\">Download Pdf"+
										"</a></span></section>";
			}
		}
		divStmtContainerList += "<article>"+divCategoryName+strProductDtls+"</article>";	
	}
	document.getElementById("treatment-container-list").innerHTML = divStmtContainerList;	
}


function downloadPdf()
{
  location.href="api/download1";

}