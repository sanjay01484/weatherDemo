document.write('<section class="brands-footer" style=\"padding-top:10px;\">');
document.write('<p style="text-align: center;">UOB GROUP:</p>');
document.write('<table width="100%" border="0" cellspacing="0" cellpadding="0">');
document.write('<tr><td colspan="3" align="center"><p style="text-align:center;height:10px;">396 Alexandra Rd, UOB Alexandra Building, Singapore 119954</p></td></tr>');
document.write('</table>'); 
document.write('</section>');
