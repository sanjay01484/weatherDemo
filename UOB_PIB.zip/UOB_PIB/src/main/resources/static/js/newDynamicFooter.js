document.write('<div class="upper-footer clearfix">');
document.write('<ul class="inner-wrapper">');
document.write('<li><p>Smarter customer journeys with UOB:</p></li>');
document.write('<span class="upper-footer-dropdown">select</span>');
	document.write('<li><a href="#" onclick=alert(under constructio); title="Connect with UOB"><img src="images/images_uob_w.png" alt="UOB Logo" class="strip-foot-image">Strip</a></li>');

