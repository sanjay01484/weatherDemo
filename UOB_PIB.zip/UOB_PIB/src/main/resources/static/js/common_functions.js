var spinnerFlag = true;
var deviceid = checkNull(sessionStorage.getItem("deviceid"));
var devicePlatform = checkNull(sessionStorage.getItem("platform"));

//	Encryption algorithm 
function encrypt(val){
	if (!encFlag)
		return val;
    var s = val;
    //log("inside encript");
    var pw = "TheBestSecretKey";
    var a=0;
    var myString='';
    var textLen=s.length;
    var pwLen=pw.length;
    for (i=0;i<textLen;i++){
        a=parseInt(s.charCodeAt(i));
        a=a^(pw.charCodeAt(i%pwLen));
        a=a+"";
        while (a.length<3)
        a='0'+a;
        
        myString+=a;
    }
    return myString;
}

//Decryption algorithm
function decript(val){
	if (!encFlag)
		return val;
    var s = val;
    var pw = "TheSecretKey";
    var myString='';
    var a=0;
    var pwLen=pw.length;
    var textLen=s.length;
    var i=0;
    var myHolder="";
    while(i<s.length-2)
    {
        myHolder=s.charAt(i)+s.charAt(i+1)+s.charAt(i+2);
        if (s.charAt(i)=='0') {
            myHolder=s.charAt(i+1)+s.charAt(i+2);
        }
        if ((s.charAt(i)=='0')&&(s.charAt(i+1)=='0')) {
            myHolder=s.charAt(i+2);
        }
        a=parseInt(myHolder);
        a=a^(pw.charCodeAt(i/3%pwLen));
        myString+=String.fromCharCode(a);
        i+=3;
    }//end of while i
    return myString;
}

setTimeout(function(){ 
	showMsg("Your session has expired.", "Session Info", "OK");	
	var uri = $(location).attr("href");
	var profileIdx = uri.indexOf("profile/profile-");
	var categoryIdx = uri.indexOf("categories/listing-");
	if (profileIdx > 0 || categoryIdx > 0)
		$(location).attr("href", "../../index.html");
	else
		$(location).attr("href", "../index.html");
}, 7200000);


function checkNull(varVal)
{
	var returnValue = varVal;	
	if(returnValue==null || returnValue == "null" || returnValue == "")
		return "";
	else
		return returnValue;

}

function logoutApp()
{
	
	location.href="http://localhost:8080/";

}

function homepag()
{
	
	location.href="http://localhost:8080/js/dash_bord.html";

}

function getSessionID(){
	var sessionID = checkNull(sessionStorage.getItem("sessionID"));
	if (sessionID == ""){
		sessionID = encrypt(""+Math.round(100000 + Math.random() * 900000));
		sessionStorage.setItem("sessionID", sessionID);
	}
	return sessionID;
}

function log(msg){
	console.log(msg);
}


function writeHeader(level){

		document.write("<nav id=\"navdropdown\"><ul class=\"nav-bar clearfix\"><li><a href=\"#\" onclick=\"homepag('../../index.html');\">Home</a></li><li><a href=\"#\" onclick=\"alert('Under Construction');\">Today</a></li><li><a href=\"#\" onclick=\"alert('Under Construction');\">Hourly</a></li><li><a href=\"#\" onclick=\"alert('Under Construction');\">10 Days</a></li><li><a href=\"#\" onclick=\"alert('Under Construction');\">Calendar</a></li><li><a href=\"#\" onclick=\"logoutApp('../../index.html');\">Logout</a></li></ul></nav>");
}
