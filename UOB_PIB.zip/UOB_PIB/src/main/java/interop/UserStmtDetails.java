package interop;

import java.util.ArrayList;

public class UserStmtDetails implements IData{
	
	ArrayList<UserDetailsInfoBean> stmtLst = new ArrayList<UserDetailsInfoBean>();
	public ArrayList<UserDetailsInfoBean> getStmtLst() {
		return stmtLst;
	}
	public void setStmtLst(ArrayList<UserDetailsInfoBean> stmtLst) {
		this.stmtLst = stmtLst;
	}
	public ArrayList<UserDetailsInfoBean> getOtherDetaisLst() {
		return otherDetaisLst;
	}
	public void setOtherDetaisLst(ArrayList<UserDetailsInfoBean> otherDetaisLst) {
		this.otherDetaisLst = otherDetaisLst;
	}
	ArrayList<UserDetailsInfoBean> otherDetaisLst = new ArrayList<UserDetailsInfoBean>();
	

}
