package interop;

import java.util.HashMap;

public class Request extends HashMap<String, IData> implements IData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String request_type;
	private String function_name;
	private UserAuthInfo userAuthInfo;;
	
	public String getRequest_Type() {
		return request_type;
	}
	public void setRequest_Type(String request_type) {
		this.request_type = request_type;
	}
	public String getFunction_Name() {
		return function_name;
	}
	public void setFunction_Name(String function_name) {
		this.function_name = function_name;
	}
	public UserAuthInfo getUserAuthInfo() {
		return userAuthInfo;
	}
	public void setUserAuthInfo(UserAuthInfo userAuthInfo) {
		this.userAuthInfo = userAuthInfo;
	}
}

