package interop;
import java.util.HashMap;
public class Response extends HashMap<String, IData> implements IData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	// responseCode = 00 - SUCCESS, 01 - Validation Error, 10 - Business Error, 11 - Critical Error
	
	private String responseCode;
	private String responseMsg;
	
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

}