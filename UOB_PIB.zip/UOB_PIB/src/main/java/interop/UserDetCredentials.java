package interop;

public class UserDetCredentials implements IData {
	
	private static final long serialVersionUID = 1L;
	private String strCustID;
	private String strCountryID;
	private String strProductID;
	private String sessionDetails;

	private String strAuthId;

	public String getStrCustID() {
		return strCustID;
	}

	public void setStrCustID(String strCustID) {
		this.strCustID = strCustID;
	}

	public String getStrCountryID() {
		return strCountryID;
	}

	public void setStrCountryID(String strCountryID) {
		this.strCountryID = strCountryID;
	}

	

	public String getSessionDetails() {
		return sessionDetails;
	}

	public void setSessionDetails(String sessionDetails) {
		this.sessionDetails = sessionDetails;
	}

	public String getStrAuthId() {
		return strAuthId;
	}

	public void setStrAuthId(String strAuthId) {
		this.strAuthId = strAuthId;
	}

	public String getStrProductID() {
		return strProductID;
	}

	public void setStrProductID(String strProductID) {
		this.strProductID = strProductID;
	}

}
