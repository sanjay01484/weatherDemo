package interop;

public class AuthCredentials implements IData {
	
	private static final long serialVersionUID = 1L;
	
	private String email;
	private String pass;
	private String deviceId;
	private String forwardPage;
	private String clientVersion;
	private String name1;
	private String name2;
	private String nric;
	private String gender;
	private String birth;
	private String mobile;
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}
	public String getName2() {
		return name2;
	}
	public void setName2(String name2) {
		this.name2 = name2;
	}
	public String getNric() {
		return nric;
	}
	public void setNric(String nric) {
		this.nric = nric;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String password;
	public String getStrCustID() {
		return strCustID;
	}
	public void setStrCustID(String strCustID) {
		this.strCustID = strCustID;
	}
	private String strCustID;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getForwardPage() {
		return forwardPage;
	}
	public void setForwardPage(String forwardPage) {
		this.forwardPage = forwardPage;
	}
	public String getClientVersion() {
		return clientVersion;
	}
	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}
}

