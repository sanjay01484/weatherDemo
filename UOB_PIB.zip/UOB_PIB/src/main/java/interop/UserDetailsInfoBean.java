package interop;

public class UserDetailsInfoBean implements IData{
	
	private static final long serialVersionUID = 1L;
	private String custId;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	public String getDrnNo() {
		return drnNo;
	}
	public void setDrnNo(String drnNo) {
		this.drnNo = drnNo;
	}
	public String getCycleDate() {
		return cycleDate;
	}
	public void setCycleDate(String cycleDate) {
		this.cycleDate = cycleDate;
	}
	private String custName;
	private String productId;
	private String productName;
	private String templateId;
	private String drnNo;
	private String cycleDate;
	

}
