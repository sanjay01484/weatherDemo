package interop;

import java.io.Serializable;

public interface IData extends Serializable{

}