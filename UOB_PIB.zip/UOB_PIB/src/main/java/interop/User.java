package interop;

public class User implements IData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAdminMessage() {
		return adminMessage;
	}
	public void setAdminMessage(String adminMessage) {
		this.adminMessage = adminMessage;
	}
	public String getBirthDay() {
		return birthDay;
	}
	public void setBirthDay(String birthDay) {
		this.birthDay = birthDay;
	}
	private String cusId;
	private String cusFirstName;
	private String cusLastName;
	private String cusGender;
	private String cusLoginEmailId;
	private String cusMobileNumber;
	private String cusContAdd1;
	private String cusIdNumber;
	private String idTypeName;
	private String state;
	private String adminMessage;
	private String birthDay;
	
	
	public String getCusId() {
		return cusId;
	}
	public void setCusId(String cusId) {
		this.cusId = cusId;
	}
	public String getCusFirstName() {
		return cusFirstName;
	}
	public void setCusFirstName(String cusFirstName) {
		this.cusFirstName = cusFirstName;
	}
	public String getCusLastName() {
		return cusLastName;
	}
	public void setCusLastName(String cusLastName) {
		this.cusLastName = cusLastName;
	}
	public String getCusGender() {
		return cusGender;
	}
	public void setCusGender(String cusGender) {
		this.cusGender = cusGender;
	}
	public String getCusLoginEmailId() {
		return cusLoginEmailId;
	}
	public void setCusLoginEmailId(String cusLoginEmailId) {
		this.cusLoginEmailId = cusLoginEmailId;
	}
	
	public String getCusMobileNumber() {
		return cusMobileNumber;
	}
	public void setCusMobileNumber(String cusMobileNumber) {
		this.cusMobileNumber = cusMobileNumber;
	}
	public String getCusContAdd1() {
		return cusContAdd1;
	}
	public void setCusContAdd1(String cusContAdd1) {
		this.cusContAdd1 = cusContAdd1;
	}
	
	public String getCusIdNumber() {
		return cusIdNumber;
	}
	public void setCusIdNumber(String cusIdNumber) {
		this.cusIdNumber = cusIdNumber;
	}
	public String getIdTypeName() {
		return idTypeName;
	}
	public void setIdTypeName(String idTypeName) {
		this.idTypeName = idTypeName;
	}
		
	
}