package interop;

public class UserStmtDetailsInfoBean implements IData{
	
	private static final long serialVersionUID = 1L;
	private String custId;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getTransDate() {
		return transDate;
	}
	public void setTransDate(String transDate) {
		this.transDate = transDate;
	}
	public String getStrCode() {
		return strCode;
	}
	public void setStrCode(String strCode) {
		this.strCode = strCode;
	}
	public String getStrRefNo() {
		return strRefNo;
	}
	public void setStrRefNo(String strRefNo) {
		this.strRefNo = strRefNo;
	}
	public String getStrDebitAmt() {
		return strDebitAmt;
	}
	public void setStrDebitAmt(String strDebitAmt) {
		this.strDebitAmt = strDebitAmt;
	}
	public String getStrCreditAmt() {
		return strCreditAmt;
	}
	public void setStrCreditAmt(String strCreditAmt) {
		this.strCreditAmt = strCreditAmt;
	}
	private String transDate;
	private String strCode;
	private String strRefNo;
	private String strDebitAmt;
	private String strCreditAmt;
	private String strSubRefNo;
	private String strMethodName;
	public String getStrMethodName() {
		return strMethodName;
	}
	public void setStrMethodName(String strMethodName) {
		this.strMethodName = strMethodName;
	}
	public String getStrSubRefNo() {
		return strSubRefNo;
	}
	public void setStrSubRefNo(String strSubRefNo) {
		this.strSubRefNo = strSubRefNo;
	}

}
