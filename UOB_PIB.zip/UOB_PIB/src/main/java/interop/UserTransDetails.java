package interop;

import java.util.ArrayList;

public class UserTransDetails implements IData{
	
	ArrayList<UserStmtDetailsInfoBean> stmtLst = new ArrayList<UserStmtDetailsInfoBean>();
	public ArrayList<UserStmtDetailsInfoBean> getUserStmtLst() {
		return stmtLst;
	}
	public void setUserStmtLst(ArrayList<UserStmtDetailsInfoBean> stmtLst) {
		this.stmtLst = stmtLst;
	}
	

}
