package interop;

public class UserAuthInfo  implements IData {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String cusId;
    private String cusLoginId;
    private String deviceId;
    private String clientVersion;
    private String serverVersion;
    private String resposeCd;
    private String responseMsg;
    
	public String getCusId() {
		return cusId;
	}
	public void setCusId(String cusId) {
		this.cusId = cusId;
	}
	public String getCusLoginId() {
		return cusLoginId;
	}
	public void setCusLoginId(String cusLoginId) {
		this.cusLoginId = cusLoginId;
	}
	public String getDeviceId() {
		return deviceId;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	public String getClientVersion() {
		return clientVersion;
	}
	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}
	public String getServerVersion() {
		return serverVersion;
	}
	public void setServerVersion(String serverVersion) {
		this.serverVersion = serverVersion;
	}
	public String getResposeCd() {
		return resposeCd;
	}
	public void setResposeCd(String resposeCd) {
		this.resposeCd = resposeCd;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
}

