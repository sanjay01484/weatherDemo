package controller;




import java.io.File;
import java.io.FileInputStream;
import java.io.IOException; 

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import uobconstant.IUOBConstant;
import uoblog.UobLogManager;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
 



import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph; 
import com.itextpdf.text.pdf.PdfWriter;

import Utility.MediaTypeUtilitly; 

@Controller
public class PdfDownloadController {
	
    private static final String DIRECTORY = "D:/PIBDOWNLOAD";
    private static final String DEFAULT_FILE_NAME = "Statement.pdf";
    private static final String CLASS_NAME = "PdfDownloadController";
    @Autowired
    private ServletContext servletContext;   
 
    // http://localhost:8080/download1?fileName=abc.zip
    // Using ResponseEntity<InputStreamResource>
    @RequestMapping("/download1") 
    public ResponseEntity<InputStreamResource> downloadFile1(
            @RequestParam(defaultValue = DEFAULT_FILE_NAME) String fileName) throws IOException {
		String METHOD_NAME = "downloadFile1"; 
        
        Document document = new Document();
        try
        {
        	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type:create file ");
           PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("D:/PIBDOWNLOAD/Statement.pdf"));
           document.open();
           document.add(new Paragraph("Monthely Statement"));
           document.close();
           writer.close();
        } catch (DocumentException e)
        {
           e.printStackTrace();
        } catch (FileNotFoundException e)
        {
           e.printStackTrace();
        }
        MediaType mediaType = MediaTypeUtilitly.getMediaTypeForFileName(this.servletContext, fileName);
         
        System.out.println("fileName: " + fileName);
        System.out.println("mediaType: " + mediaType);
 
        File file = new File(DIRECTORY + "/" + fileName);
        InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
 
        return ResponseEntity.ok()
                // Content-Disposition
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=" + file.getName())
                // Content-Type
                .contentType(mediaType)
                // Contet-Length
                .contentLength(file.length()) //
                .body(resource);
    }

    
    
}
