package controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Map;
import java.util.*;

import com.google.gson.*;
import com.google.gson.reflect.*;

public class weatherRead{
	
	public  Map<String,Object> jsonToMap(String str)
	{
		Map<String, Object> map = new Gson().fromJson(
				str,new TypeToken<HashMap<String, Object>>(){}.getType());
		return map;
	}
	
	

   public void weatherDet() {
    
   
    	
    	 String API_KEY = "10529f0644cca14fc7c2167bdcd309ba";
    	 String location = "295kn26";
    	 String API_URL = "https://api.darksky.net/forecast/f205c5f32648d3acf1e092b80b4201b0/42.3601,-71.0589";
     	
    	try
    	{
    		StringBuilder result = new StringBuilder();
    		URL url = new URL(API_URL);
    		URLConnection conn = url.openConnection();
    		BufferedReader bf = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    		String line;
    		while((line = bf.readLine()) != null){
    			result.append(line);
    		  }
    		  bf.close();
    		System.out.println(result);
    		
    		Map<String,Object> readMap= jsonToMap(result.toString());
    		Map<String,Object> currently= jsonToMap(readMap.get("currently").toString());
    		//Map<String,Object> minutely= jsonToMap(readMap.get("minutely").toString());
    		Map<String,Object> hourly= jsonToMap(readMap.get("hourly").toString());
    		System.out.println("Current Temprature" + currently.get("time"));
    	} 
    	catch (IOException pe){
			pe.printStackTrace();	
       }
    }
  }
    	
    	
 