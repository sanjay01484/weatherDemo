package exception;

public class UOBCriticalException extends UOBAppException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UOBCriticalException(){
		super();
	}
	
	public UOBCriticalException(String message){
		super(message);
	}

}

