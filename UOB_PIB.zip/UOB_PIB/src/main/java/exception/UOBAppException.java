package exception;

public class UOBAppException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UOBAppException(){
		super();
	}
	
	public UOBAppException(String message){
		super(message);
	}
	
}

