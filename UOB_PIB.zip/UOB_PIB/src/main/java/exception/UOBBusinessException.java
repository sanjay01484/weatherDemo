package exception;

public class UOBBusinessException  extends UOBAppException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UOBBusinessException(){
		super();
	}
	
	public UOBBusinessException(String message){
		super(message);
	}

}

