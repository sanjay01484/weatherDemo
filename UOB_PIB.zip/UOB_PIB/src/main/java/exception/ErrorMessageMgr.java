package exception;
import java.util.HashMap;
import java.util.Properties;
import uoblog.UobLogManager;

public class ErrorMessageMgr {
	
	private static ErrorMessageMgr INSTANCE;
	private static HashMap<String, String> errMsgMap = new HashMap<String, String>();
	private static final String CLASS_NAME = "ErrorMessageMgr";
	
	private ErrorMessageMgr(){
		init();
	}

	private void init() {
		String METHOD_NAME = "init()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside init()");
		
		Properties properties = new Properties();
	    try {
	    	properties.load(ErrorMessageMgr.class.getResourceAsStream("error_msg.properties"));
	    	for(String key : properties.stringPropertyNames()) {
	    		  String value = properties.getProperty(key);
	    		  //UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Key ["+key + "] => value [" + value +"]");
	    		  UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Key ["+key + "] => value [" + value +"]");
	    		  errMsgMap.put(key, value);
	    	}
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit From init()");
	}
	
	public String getMessage(String errCode){
		return errMsgMap.get(errCode);
	}
	
	public static ErrorMessageMgr getInstance() {
		String METHOD_NAME = "init()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside getInstance()");
		
		if (null == INSTANCE) {
			INSTANCE = new ErrorMessageMgr();
		}
		
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit From getInstance()");
		return INSTANCE;
	}

}
