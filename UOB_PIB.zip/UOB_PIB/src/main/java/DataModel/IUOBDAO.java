package DataModel;
import interop.Request;
import interop.Response;
import exception.*;
public interface IUOBDAO {

	public Response execute(Request request) throws UOBCriticalException, UOBBusinessException, Exception;

	}