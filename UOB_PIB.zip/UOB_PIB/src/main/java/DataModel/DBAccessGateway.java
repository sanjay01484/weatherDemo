package DataModel;

import interop.Request;
import interop.Response;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import service.ServiceLocator;
import uoblog.UobLogManager;
import exception.UOBBusinessException;
import exception.UOBCriticalException;
public class DBAccessGateway implements IAccessGateway {
	
	private static DBAccessGateway INSTANCE;
	private static Map<String, Object> daoMap = new HashMap<String, Object>();
	private static final String CLASS_NAME = "DBAccessGateway";
	private static int connCounter = 0;
	
	private DBAccessGateway(){ 
		init();
	}
	
	private void init() {
		String METHOD_NAME = "init()";
		 
	    try {
    		  UserAuthenticateDAOImpl userAuthenticateDAOImpl = new UserAuthenticateDAOImpl();
    		    
    		  daoMap.put("AUTHENTICATE_SERVICE", userAuthenticateDAOImpl);
    		
    		 
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    
	}
	
	public Connection getDBConnection() throws SQLException{
		String METHOD_NAME = "getDBConnection()";		
		Connection con = null;
		DataSource ds = ServiceLocator.getSingletonInstance().getDatSource();
		if(ds != null)
			con =  ds.getConnection();
		
		connCounter++;		
		return con;
	}
	
	public void closeConnection(Connection con) throws SQLException{
		String METHOD_NAME = "getDBConnection()";
		if(con != null)
			con .close();
		
		connCounter--;		
	}
	
	public void beginTransaction(Connection con) throws SQLException{
		String METHOD_NAME = "beginTransaction()";		
		if(con != null)
			con.setAutoCommit(false);		
	}
	
	public void commitTransaction(Connection con) throws SQLException{
		String METHOD_NAME = "commitTransaction()";		
		if(con != null)
			con.commit();		
	}
	
	public void rollbackTransaction(Connection con) throws SQLException{
		String METHOD_NAME = "rollbackTransaction()";
		if(con != null)
			con.rollback();
	}
	
	public static DBAccessGateway getInstance() {
		String METHOD_NAME = "getInstance()";
		if (null == INSTANCE) {
			INSTANCE = new DBAccessGateway();
		}		
		return INSTANCE;
	}

	@Override
	public Response execute(Request request) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "execute";
		Response response = null;
		String request_type = request.getRequest_Type();
		IUOBDAO dao = (IUOBDAO) daoMap.get(request_type);
		if (dao != null){
			try{
				response = (Response) dao.execute(request);
			}catch(Exception ex){
				UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex.getCause().getMessage());
				UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getCause().getMessage());
				throw new UOBCriticalException(ex.getMessage());
			}	
		}else{
			System.out.println("Implementation not found for request_type ["+request_type+"]");
		}		
		return response;
	}

	public static int getConnCounter() {
		return connCounter;
	}
}
