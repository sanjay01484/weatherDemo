package DataModel;

import interop.AuthCredentials;
import interop.Request;
import interop.Response;
import interop.User;
import interop.UserDetailsInfoBean;
import interop.UserStmtDetails;
import interop.UserStmtDetailsInfoBean;
import interop.UserTransDetails;

import java.util.ArrayList;
import java.util.Date;

import uobconstant.IUOBConstant;
import uoblog.UobLogManager;
import Utility.Utils;
import exception.UOBBusinessException;
import exception.UOBCriticalException;
public class UserAuthenticateDAOImpl  implements IUOBDAO {
	
	private static final String CLASS_NAME = "UserAuthenticateDAOImpl";
	
	@Override
	public Response execute(Request request) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "execute";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute");
		
		Response response = null;
		String function =  request.getFunction_Name(); 
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute fn "+function);
		if (IUOBConstant.FUNCTION_AUTHENTICATE.equals(function)){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute fn SANJAY"+IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute fn SANJAY44444"+((AuthCredentials)request.get("auth_credentials")).getEmail().toString());
			AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute credentials 4444"+credentials.getEmail());
			response = authenticate(credentials);
		}else if(IUOBConstant.FUNCTION_GET_USER_DETAILS.equals(function)){
			AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute getUserDetails "+IUOBConstant.FUNCTION_GET_USER_DETAILS);
			response = getUserDetails(credentials);
		}else if(IUOBConstant.FUNCTION_GET_TRANS_DETAILS.equals(function)){
			AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute getUserDetails "+IUOBConstant.FUNCTION_GET_TRANS_DETAILS);
			response = getUserTransDetails(credentials);
		}
		else if(IUOBConstant.FUNCTION_GET_DASHBOARD_DETAILS.equals(function)){
			AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute getUserDetails "+IUOBConstant.FUNCTION_GET_DASHBOARD_DETAILS);
			response = getUserDashBoarDetails(credentials);
		}
		
		else if(IUOBConstant.FUNCTION_SET_USERINSERT_DETAILS.equals(function)){
			AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute getUserDetails "+IUOBConstant.FUNCTION_SET_USERINSERT_DETAILS);
			response = setUserInsert(credentials);
		}
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From execute");
		return response;
	}
	
	private Response authenticate(AuthCredentials credentials) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "authenticate";
		Response response = new Response();
		User user = null;
		
		//Connection conn = null;
		//CallableStatement cstmt = null;
		//ResultSet rs = null;
		String success = null;   
		String custId = null;
		String countryPk1 = "1000";
		String deviceId = credentials.getDeviceId();
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute deviceId "+deviceId);
		String today = Utils.formatDate(new Date(), "yyyy-MM-dd hh:mm:ss");
		
		String emailId = credentials.getEmail();
		String pwd = credentials.getPass();
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "User ID: ["+credentials.getEmail()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Device ID: ["+credentials.getDeviceId()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "today: ["+today+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "pwd: ["+Utils.getHexString(pwd.getBytes())+"]");
		int versionCheck = 2;
		
		//DBAccessGateway dbag = DBAccessGateway.getInstance();
		try{
			/*conn = dbag.getDBConnection();
			cstmt = conn.prepareCall("{call }");
			cstmt.setString(3, ); 
			cstmt.setString(6, );

			cstmt.execute();
*/
			//success = (String) cstmt.getObject(2);
			success = "-";
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "success: ["+success+"]");
			
		
			if ("-".equalsIgnoreCase(success)|| "FL".equalsIgnoreCase(success)) {
					user = new User();
				
						custId = Utils.checkNull("11112");
						user.setCusId(custId);
						user.setCusFirstName("UOB");
						user.setCusLastName("UOB123");
						user.setCusGender("M");
						user.setCusLoginEmailId("success130@gmail.com");
						user.setCusMobileNumber("+6598991478");
						user.setCusContAdd1("Yishun");
						user.setBirthDay("10/12/1983");
						user.setState("SINGAPORE");
				
					    String adminMsg = "Admin Success";
					    user.setAdminMessage(adminMsg);
				    response.setResponseCode(IUOBConstant.RESPONSE_CODE_SUCCESS);
				    response.put(IUOBConstant.USER_DETAILS_OBJECT, user);
			}else{
				response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
					response.setResponseMsg(success);
			}
		}catch(Exception ex){
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
			throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_000, new Object [] {ex.getMessage()}));
		}finally{
			try{
				
				UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "User ID: ["+credentials.getEmail()+"]");
			
			}catch(Exception ex){
				UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
		    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
		    	throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_002, new Object [] {ex.getMessage()}));
			}
		}
		
		return response;
	}
	
	
	
	private Response getUserDetails(AuthCredentials credentials) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "getUserDetails";
		Response response = new Response();
		UserDetailsInfoBean bean = null;
		UserStmtDetails details = new UserStmtDetails();
		String newCPSId = "";
		String oldCPSId = "";
		String segId = "";

		/*Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
*/		String success = null;
		ArrayList<UserDetailsInfoBean> beanLst = new ArrayList<UserDetailsInfoBean>();
		//DBAccessGateway dbag = DBAccessGateway.getInstance();
		
		try {
/*			conn = dbag.getDBConnection();
			cstmt = conn.prepareCall("{call }");
			cstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
			cstmt.setString(2, "");
			cstmt.setString(3, "");
			cstmt.setString(4, "");
			cstmt.execute();
			success="-";
*/			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "success: ["+ success + "]");

/*			rs = (ResultSet) cstmt.getObject(1);
			if (rs != null) {
				while (rs.next()) {
				
		
*/					bean = new UserDetailsInfoBean();
					bean.setCustName("Sanajy Kumar");
					bean.setProductId("001");
					bean.setProductName("Temprature");
					bean.setTemplateId("N");
					bean.setDrnNo("234243234234234234234");
					bean.setCycleDate("May Month");
					beanLst.add(bean);
					
					bean = new UserDetailsInfoBean();
					bean.setCustName("Sanajy Kumar2");
					bean.setProductId("002");
					bean.setProductName("Humidity");
					bean.setTemplateId("H");
					bean.setDrnNo("23424323433334234234234");
					bean.setCycleDate("May Month");
					beanLst.add(bean);
					
					bean = new UserDetailsInfoBean();
					bean.setCustName("Sanajy Kumar2");
					bean.setProductId("003");
					bean.setProductName("Dew Point");
					bean.setTemplateId("C");
					bean.setDrnNo("23424323433334234234234");
					bean.setCycleDate("May Month");
					beanLst.add(bean);
					
					bean = new UserDetailsInfoBean();
					bean.setCustName("Sanajy Kumar2");
					bean.setProductId("002");
					bean.setProductName("Wind");
					bean.setTemplateId("CP");
					bean.setDrnNo("23424323433334234234234");
					bean.setCycleDate("May Month");
					beanLst.add(bean);
					
					bean = new UserDetailsInfoBean();
					bean.setCustName("Sanajy Kumar2");
					bean.setProductId("002");
					bean.setProductName("Heat Index");
					bean.setTemplateId("CP");
					bean.setDrnNo("23424323433334234234234");
					bean.setCycleDate("May Month");
					beanLst.add(bean);
					
				//}
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails List: ["+ beanLst.size() + "]");
			if (beanLst.size() > 0) {
				details.setStmtLst(beanLst);
			}
		} catch(Exception ex) {
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails Exception: ");
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
			throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_003, new Object[] { ex.getMessage() }));
	
		}
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails out side: "+IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.setResponseCode(IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.put(IUOBConstant.USER_STMT_DETAILS_OBJECT, details);		
		return response;
	}
	
	private Response getUserTransDetails(AuthCredentials credentials) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "getUserTransDetails";
		Response response = new Response();
		UserStmtDetailsInfoBean bean = null;
		UserTransDetails details = new UserTransDetails();
		String newCPSId = "";
		String oldCPSId = "";
		String segId = "";

		/*Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
*/		String success = null;
		ArrayList<UserStmtDetailsInfoBean> beanLst = new ArrayList<UserStmtDetailsInfoBean>();
		//DBAccessGateway dbag = DBAccessGateway.getInstance();
		
		try {
/*			conn = dbag.getDBConnection();
			cstmt = conn.prepareCall("{call }");
			cstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
			cstmt.setString(2, "");
			cstmt.setString(3, "");
			cstmt.setString(4, "");
			cstmt.execute();
			success="-";
*/			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails success: ["+ success + "]");

/*			rs = (ResultSet) cstmt.getObject(1);
			if (rs != null) {
				while (rs.next()) {
				
		
*/					bean = new UserStmtDetailsInfoBean();
					bean.setTransDate("merica/New_York");
					bean.setStrCode("37.63");
					bean.setStrRefNo("6.64");
					bean.setStrDebitAmt("0.93");
					bean.setStrDebitAmt("0.93");
					bean.setStrCreditAmt("1002");
					beanLst.add(bean);
					bean = new UserStmtDetailsInfoBean();
					bean.setTransDate("merica/New_York");
					bean.setStrCode("37.63");
					bean.setStrRefNo("6.64");
					bean.setStrDebitAmt("0.93");
					bean.setStrDebitAmt("0.93");
					bean.setStrCreditAmt("1002");
					beanLst.add(bean);
					bean = new UserStmtDetailsInfoBean();
					bean.setTransDate("merica/New_York");
					bean.setStrCode("37.63");
					bean.setStrRefNo("6.64");
					bean.setStrDebitAmt("0.93");
					bean.setStrDebitAmt("0.93");
					bean.setStrCreditAmt("1002");
					beanLst.add(bean);
					bean = new UserStmtDetailsInfoBean();
					bean.setTransDate("merica/New_York");
					bean.setStrCode("37.63");
					bean.setStrRefNo("6.64");
					bean.setStrDebitAmt("0.93");
					bean.setStrDebitAmt("0.93");
					bean.setStrCreditAmt("1002");
					beanLst.add(bean);
					
				//}
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails List: ["+ beanLst.size() + "]");
			if (beanLst.size() > 0) {
				details.setUserStmtLst(beanLst);
			}
		} catch(Exception ex) {
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails Exception: ");
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
			throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_003, new Object[] { ex.getMessage() }));
	
		}
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails out side: "+IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.setResponseCode(IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.put(IUOBConstant.USER_STMT_DETAILS_OBJECT, details);		
		return response;
	}

	
	private Response getUserDashBoarDetails(AuthCredentials credentials) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "getUserDashBoarDetails";
		Response response = new Response();
		UserStmtDetailsInfoBean bean = null;
		UserTransDetails details = new UserTransDetails();
		String newCPSId = "";
		String oldCPSId = "";
		String segId = "";

		/*Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
*/		String success = null;
		ArrayList<UserStmtDetailsInfoBean> beanLst = new ArrayList<UserStmtDetailsInfoBean>();
		//DBAccessGateway dbag = DBAccessGateway.getInstance();
		
		try {
/*			conn = dbag.getDBConnection();
			cstmt = conn.prepareCall("{call }");
			cstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
			cstmt.setString(2, "");
			cstmt.setString(3, "");
			cstmt.setString(4, "");
			cstmt.execute();
			success="-";
*/			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails success: ["+ success + "]");

/*			rs = (ResultSet) cstmt.getObject(1);
			if (rs != null) {
				while (rs.next()) {
				
		
*/					bean = new UserStmtDetailsInfoBean();
					bean.setStrCode("1");
					bean.setStrRefNo("View WeatherData  History");
					bean.setStrSubRefNo("Current Weather Data");
					bean.setStrMethodName("getTransDet");
					beanLst.add(bean);
					bean = new UserStmtDetailsInfoBean();
					bean.setStrCode("2");
					bean.setStrRefNo("DownLoad WeatherData");
					bean.setStrSubRefNo("Download pdf");
					bean.setStrMethodName("handelClick");
					beanLst.add(bean);
					
					
					
				//}
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails List: ["+ beanLst.size() + "]");
			if (beanLst.size() > 0) {
				details.setUserStmtLst(beanLst);
			}
		} catch(Exception ex) {
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails Exception: ");
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
			throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_003, new Object[] { ex.getMessage() }));
	
		}
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails out side: "+IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.setResponseCode(IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.put(IUOBConstant.USER_STMT_DETAILS_OBJECT, details);		
		return response;
	}
	
	private Response setUserInsert(AuthCredentials credentials) throws UOBCriticalException, UOBBusinessException, Exception{
		String METHOD_NAME = "setUserInsert";
		Response response = new Response();
		UserStmtDetailsInfoBean bean = null;
		UserTransDetails details = new UserTransDetails();
		String newCPSId = "";
		String oldCPSId = "";
		String segId = "";

		/*Connection conn = null;
		CallableStatement cstmt = null;
		ResultSet rs = null;
*/		String success = null;
		ArrayList<UserStmtDetailsInfoBean> beanLst = new ArrayList<UserStmtDetailsInfoBean>();
		//DBAccessGateway dbag = DBAccessGateway.getInstance();
		
		try {
/*			conn = dbag.getDBConnection();
			cstmt = conn.prepareCall("{call }");
			cstmt.registerOutParameter(1, oracle.jdbc.OracleTypes.CURSOR);
			cstmt.setString(2, "");
			cstmt.setString(3, "");
			cstmt.setString(4, "");
			cstmt.execute();
			success="-";
*/			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails success: ["+ success + "]");
            UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME,"UserTransDetails getGender:"+ credentials.getGender());
            UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME,"UserTransDetails getGender:"+ credentials.getBirth());

/*			rs = (ResultSet) cstmt.getObject(1);
			if (rs != null) {
				while (rs.next()) {
				
		
*/					bean = new UserStmtDetailsInfoBean();
					bean.setStrCode("1");
					bean.setStrRefNo("View WeatherData  History");
					bean.setStrSubRefNo("Current Weather Data");
					bean.setStrMethodName("getTransDet");
					beanLst.add(bean);
					
					
					
				//}
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails List: ["+ beanLst.size() + "]");
			if (beanLst.size() > 0) {
				details.setUserStmtLst(beanLst);
			}
		} catch(Exception ex) {
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserDetails Exception: ");
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex);
			throw new UOBCriticalException(Utils.getErrorMessage(IUOBConstant.DB_003, new Object[] { ex.getMessage() }));
	
		}
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserTransDetails out side: "+IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.setResponseCode(IUOBConstant.RESPONSE_CODE_SUCCESS);
		response.put(IUOBConstant.USER_STMT_DETAILS_OBJECT, details);		
		return response;
	}
}

