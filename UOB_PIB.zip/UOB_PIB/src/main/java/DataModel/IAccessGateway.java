package DataModel;
import interop.Request;
import interop.Response;
import exception.*;
public interface IAccessGateway {

	public Response execute(Request request) throws UOBCriticalException, UOBBusinessException, Exception;
	
}
