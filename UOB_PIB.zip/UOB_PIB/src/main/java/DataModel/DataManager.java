package DataModel;
import uoblog.UobLogManager;
import interop.Request;
import interop.Response;
import java.util.HashMap;
import java.util.Map;
import exception.*;
public class DataManager implements IDataManager{
	
	private static DataManager INSTANCE;
	private static Map<String, Object> dmMap = new HashMap<String, Object>();
	private static final String CLASS_NAME = "DataManager";
	
	private DataManager(){
		init();
	}

	private void init() {
		String METHOD_NAME = "init()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside init() DataManager");
		
	    try {
			  DBAccessGateway dbAccessGateway= DBAccessGateway.getInstance();
			
			  
			  dmMap.put("AUTHENTICATE_SERVICE", dbAccessGateway);
			  dmMap.put("USER_SERVICE", dbAccessGateway);
			 
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    
	    UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit From init()");
	}
	
	public static DataManager getInstance() {
		String METHOD_NAME = "getInstance()";
		if (null == INSTANCE) {
			INSTANCE = new DataManager();
		}		
		return INSTANCE;
	}

	@Override
	public Response execute(Request request) throws UOBCriticalException, UOBBusinessException, Exception {
		String METHOD_NAME = "execute";
		Response response = null;
		String request_type = request.getRequest_Type();
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "execute SANJAY2 request type()"+request_type);
		
		IAccessGateway accessGateway = (IAccessGateway) dmMap.get(request_type);
		try{
			response = (Response) accessGateway.execute(request);
		}catch(Exception ex){
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getCause().getMessage());
			throw new UOBCriticalException(ex.getMessage());
		}
		return response;
	}
}
