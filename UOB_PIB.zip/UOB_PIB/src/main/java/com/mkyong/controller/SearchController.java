package com.mkyong.controller;

import interop.AuthCredentials;
import interop.Request;
import interop.Response;
import interop.User;
import interop.UserStmtDetails;
import interop.UserTransDetails;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import service.IAuthenticateService;
import service.IServiceHandler;
import service.ServiceHandler;
import uobconstant.IUOBConstant;
import uoblog.UobLogManager;
import Utility.Utils;

import com.google.gson.Gson;
import com.mkyong.services.UserService;

@RestController
public class SearchController implements IAuthenticateService {

    UserService userService;
    private static final String CLASS_NAME = "SearchController";
    @Autowired
    public void setUserService(UserService userService) {
        this.userService = userService;
    } 
    @PostMapping("/api/search")
	public String authenticateUser(@Valid @RequestBody AuthCredentials product ) { 
		String METHOD_NAME = "authenticateUser"; 
		String result = null;    
		long t1 = System.currentTimeMillis();
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "AuthenticateService Initiated: "+t1);
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside authenticateUser");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+product.getEmail()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Password: ["+product.getPass()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Device ID: ["+product.getDeviceId()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "After Decrypt ...");
		String email = "";
		String pass = "";
		
			email = product.getEmail();
			pass = product.getPass();
		
		String deviceId = Utils.checkNull(product.getDeviceId());
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+email+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Device ID: ["+deviceId+"]");
		product.setEmail(product.getEmail());
		product.setPass(product.getPass());
		product.setDeviceId(product.getDeviceId());
		
		Request request = new Request();
		request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
		
		request.setFunction_Name(IUOBConstant.FUNCTION_AUTHENTICATE);
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type: ["+IUOBConstant.AUTHENTICATE_SERVICE+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Function_Name: ["+request.getFunction_Name()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj666666666: "+product.getEmail());
		request.put(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT, product);
		
		IServiceHandler serviceHandler = ServiceHandler.getInstance();
		Response response = serviceHandler.execute(request);
		User user = (User) response.get(IUOBConstant.USER_DETAILS_OBJECT);
		
		if (user != null){   
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "In side user1234: ["+response.getResponseCode()+"]");
			Gson gSon = new Gson();
			result = gSon.toJson(user);
		}else{
			String errorCode = response.getResponseCode();
			String errorMsg = response.getResponseMsg();
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorCode: ["+errorCode+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorMsg: ["+errorMsg+"]");
			if (IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR.equals(errorCode))
				result = "ERROR: " + errorMsg;
			else
				result = "ERROR: ";
		}
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from authenticateUser");
		
		return result;
	}
    @PostMapping("/api/userdet")
	public String getCustDTLS(@Valid @RequestBody AuthCredentials userdet ) { 
		String METHOD_NAME = "getCustDTLS"; 
		String result = null;    
		long t1 = System.currentTimeMillis();  
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getCustDTLS Started ");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getCustDTLS Initiated: "+t1);
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+userdet.getStrCustID()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "After Decrypt .getCustDTLS..");
		userdet.setStrCustID(userdet.getStrCustID());
		
		Request request = new Request();
		request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
		
		request.setFunction_Name(IUOBConstant.FUNCTION_GET_USER_DETAILS);
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type: ["+IUOBConstant.CUST_HISTORY_SERVICE+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Function_Name: ["+request.getFunction_Name()+"]");
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj777: "+userdet.getEmail());
		request.put(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT, userdet);
		
		IServiceHandler serviceHandler = ServiceHandler.getInstance();
		Response response = serviceHandler.execute(request);
		UserStmtDetails userStmtDetails = (UserStmtDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
		
		if (userStmtDetails != null){   
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "In side getCustDTLS Bean: ["+response.getResponseCode()+"]");
			Gson gSon = new Gson();
			result = gSon.toJson(userStmtDetails);
		}else{
			String errorCode = response.getResponseCode();
			String errorMsg = "success";//response.getResponseMsg();
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorCode: ["+errorCode+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorMsg: ["+errorMsg+"]");
			if (IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR.equals(errorCode))
				result = "ERROR: " + errorMsg;
			else
				result = "ERROR: ";
		}
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from getCustDTLS");
		
		return result;
	}
    
    @PostMapping("/api/transdet")
 	public String getTransDTLS(@Valid @RequestBody AuthCredentials userdet ) { 
 		String METHOD_NAME = "getTransDTLS"; 
 		String result = null;    
 		long t1 = System.currentTimeMillis();  
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getTransDTLS Started ");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getTransDTLS Initiated: "+t1);
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+userdet.getStrCustID()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "After Decrypt .getTransDTLS..");
 		userdet.setStrCustID(userdet.getStrCustID());
 		
 		Request request = new Request();
 		request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
 		
 		request.setFunction_Name(IUOBConstant.FUNCTION_GET_TRANS_DETAILS);
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type: ["+IUOBConstant.CUST_TRANS_SERVICE+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Function_Name: ["+request.getFunction_Name()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj777: "+userdet.getPass());
 		request.put(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT, userdet);
 		
 		IServiceHandler serviceHandler = ServiceHandler.getInstance();
 		Response response = serviceHandler.execute(request);
 		UserTransDetails userTransDetails = (UserTransDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
 		
 		if (userTransDetails != null){   
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "In side getCustDTLS Bean: ["+response.getResponseCode()+"]");
 			Gson gSon = new Gson();
 			result = gSon.toJson(userTransDetails);
 		}else{
 			String errorCode = response.getResponseCode();
 			String errorMsg = "success";//response.getResponseMsg();
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorCode: ["+errorCode+"]");
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorMsg: ["+errorMsg+"]");
 			if (IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR.equals(errorCode))
 				result = "ERROR: " + errorMsg;
 			else
 				result = "ERROR: ";
 		}
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from getCustDTLS");
 		
 		return result;
 	}
    
    @PostMapping("/api/dashboard")
 	public String getDashBoardDTLS(@Valid @RequestBody AuthCredentials userdet ) { 
 		String METHOD_NAME = "getDashBoardDTLS"; 
 		String result = null;    
 		long t1 = System.currentTimeMillis();  
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getDashBoardDTLS Started ");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "getDashBoardDTLS Initiated: "+t1);
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+userdet.getStrCustID()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "After Decrypt .getDashBoardDTLS..");
 		userdet.setStrCustID(userdet.getStrCustID());
 		
 		Request request = new Request();
 		request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
 		
 		request.setFunction_Name(IUOBConstant.FUNCTION_GET_DASHBOARD_DETAILS);
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type: ["+IUOBConstant.CUST_DASHBOARD_SERVICE+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Function_Name: ["+request.getFunction_Name()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj777: "+userdet.getPass());
 		request.put(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT, userdet);
 		
 		IServiceHandler serviceHandler = ServiceHandler.getInstance();
 		Response response = serviceHandler.execute(request);
 		UserTransDetails userTransDetails = (UserTransDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
 		
 		if (userTransDetails != null){   
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "In side getCustDTLS Bean: ["+response.getResponseCode()+"]");
 			Gson gSon = new Gson();
 			result = gSon.toJson(userTransDetails);
 		}else{
 			String errorCode = response.getResponseCode();
 			String errorMsg = "success";//response.getResponseMsg();
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorCode: ["+errorCode+"]");
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorMsg: ["+errorMsg+"]");
 			if (IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR.equals(errorCode))
 				result = "ERROR: " + errorMsg;
 			else
 				result = "ERROR: ";
 		}
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from getCustDTLS");
 		
 		return result;
 	}
    @PostMapping("/api/userinsert")
 	public String setUserInsertDTLS(@Valid @RequestBody AuthCredentials userdet ) { 
 		String METHOD_NAME = "userinsert"; 
 		String result = null;    
 		long t1 = System.currentTimeMillis();  
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "userinsert Started ");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "userinsert Initiated: "+t1);
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "UserID: ["+userdet.getStrCustID()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "After Decrypt .userinsert..");
 		userdet.setStrCustID(userdet.getStrCustID());
 		
 		Request request = new Request();
 		request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
 		
 		request.setFunction_Name(IUOBConstant.FUNCTION_SET_USERINSERT_DETAILS);
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Request_Type: ["+IUOBConstant.CUST_INSERT_SERVICE+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Setting Function_Name: ["+request.getFunction_Name()+"]");
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj777: "+userdet.getName1());
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "setObj777: "+userdet.getGender());
 		request.put(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT, userdet);
 		
 		IServiceHandler serviceHandler = ServiceHandler.getInstance();
 		Response response = serviceHandler.execute(request);
 		UserTransDetails userTransDetails = (UserTransDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
 		
 		if (userTransDetails != null){   
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "In side getCustDTLS Bean: ["+response.getResponseCode()+"]");
 			Gson gSon = new Gson();
 			result = gSon.toJson(userTransDetails);
 		}else{
 			String errorCode = response.getResponseCode();
 			String errorMsg = "success";//response.getResponseMsg();
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorCode: ["+errorCode+"]");
 			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "errorMsg: ["+errorMsg+"]");
 			if (IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR.equals(errorCode))
 				result = "ERROR: " + errorMsg;
 			else
 				result = "ERROR: ";
 		}
 		
 		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from getCustDTLS");
 		
 		return result;
 	}
    
    @PostMapping("/api/showstmt")
    public String index() { 
    	String METHOD_NAME = "index"; 
    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from index sanjay 2");
        return "uobseg/index_listing.html";
    }
    
    

}
