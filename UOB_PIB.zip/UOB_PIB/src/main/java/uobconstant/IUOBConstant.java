package uobconstant;

public class IUOBConstant {
	
//  Response Codes
	public static final String RESPONSE_CODE_SUCCESS = "00";
	public static final String RESPONSE_CODE_VALIDATION_ERROR = "01";
	public static final String RESPONSE_CODE_BUSINESS_ERROR = "10";
	public static final String RESPONSE_CODE_CRITICAL_ERROR = "11";
	
	public static final String TRUE = "TRUE";
	public static final String FALSE = "FALSE";
	public static final String ENC_FLAG = "encFlag";
	public static final String ENC_DEC_KEY = "TheBestSecretKey";
	
	//	AccessGateway constants
	public static final String DB_ACCESS_GATEWAY = "DB_ACCESS_GATEWAY";
	
	//	REQUEST_TYPE
	public static final String AUTHENTICATE_SERVICE = "AUTHENTICATE_SERVICE";
	public static final String CUST_HISTORY_SERVICE = "CUST_HISTORY_SERVICE";
	public static final String CUST_TRANS_SERVICE = "CUST_TRANS_SERVICE";
	public static final String CUST_DASHBOARD_SERVICE = "CUST_DASHBOARD_SERVICE";
	public static final String CUST_INSERT_SERVICE = "CUST_INSERT_SERVICE";
	public static final String AUTHENTICATE_CREDENTIAL_OBJECT = "auth_credentials";
	public static final String USER_DETAILS_OBJECT = "user_object";
	public static final String USER_SERVICE = "USER_SERVICE";
	public static final String USER_STMT_DETAILS_OBJECT = "user_stmt_details_object";
	//	FUNCATION_NAMES
	public static final String FUNCTION_AUTHENTICATE = "authenticate";
	public static final String FUNCTION_GET_USER_DETAILS = "getUserDetails";
	public static final String FUNCTION_GET_TRANS_DETAILS = "getTransDetails";
	public static final String FUNCTION_GET_DASHBOARD_DETAILS = "getDashBoardDetails";
	public static final String FUNCTION_SET_USERINSERT_DETAILS = "setUserInsertDet";
	public static final String DB_003 =  "DB_003";
	public static final String FUNCTION_CHECK_STATUS = "checkStatus";

	
	// Generic constants
	public static final String CUSTOMER_ID = "custId";
	public static final String SQL_SUCCESS_FLAG_S = "S";
	public static final String SQL_SUCCESS_FLAG_HYPHEN = "-";
	public static final String SQL_CLOSED_FLAG_CL = "CL";
	public static final String SQL_DISALLOWED_FLAG_DIS = "dis";
	public static final String INVALID_LOGIN_USERID = "user.l.invalid";
	public static final String INVALID_LOGIN_PWD = "user.p.invalid";
	public static final String INVALID_LOGIN_UID_PWD = "user.lp.invalid";
	public static final String USER_DOES_NOT_EXISTS = "user.invalid";
	public static final String DB_LOGIN_INACTIVE_USER = "user.inactive";
	public static final String ACTIVE_USER_STATUS = "A";
	public static final String INACTIVE_USER_STATUS = "I";
	public static final String POS_USER_STATUS = "S";
	public static final String INVALID_USER_STATUS = "F";
	public static final String MULTIPLE_USER_STATUS = "M";
	public static final String NEW_USER_STATUS = "N";
	//	Service Locator defination
	public static final String DB_JNDI_NAME = "DB_JNDI_NAME";
	public static final String LOOK_UP_STRING = "LOOK_UP_STRING";
	public static final String HOST_URL = "HOST_URL";
	public static final String ONLINE_URL = "ONLINE_URL";
	public static final String HOST_CONTEXT = "HOST_CONTEXT";
	public static final String ONLINE_CONTEXT = "ONLINE_CONTEXT";
	public static final String DMAIL =  "DEMAIL";
	public static final String DB_000 =  "DB_000";
	public static final String DB_001 =  "DB_001";
	public static final String DB_002 =  "DB_002";
	
}
