package Utility;
import uoblog.UobLogManager;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import exception.ErrorMessageMgr;
import uobconstant.IUOBConstant;

public class Utils {
	private static final String CLASS_NAME = "Utils";
	private static final char[] HEX_CHARS = new char[]{'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

	public static String hexString (byte nibbles) throws Exception{
	   return "" + HEX_CHARS [0x0F & (nibbles >> 4)] + HEX_CHARS [0x0F & nibbles];
	}

	public static String getHexString (byte[] nibbles) throws Exception{
		String hStr="";
		for(int i=0;i<nibbles.length;i++){
			hStr = hStr+ hexString(nibbles[i]);
		}
		return hStr;	   
	}
	
	public static String getStackTrace(Throwable aThrowable) {
	    final Writer result = new StringWriter();
	    final PrintWriter printWriter = new PrintWriter(result);
	    aThrowable.printStackTrace(printWriter);
	    return result.toString();
	}
	
	public static String getErrorMessage(String errCode, Object[] messages){
		
		ErrorMessageMgr err = ErrorMessageMgr.getInstance(); 
		String errMsg = err.getMessage(errCode);
		return MessageFormat.format(errMsg, messages);
		
	}
	
	public static String checkNull(String inData) {
		if (inData == null || !(inData instanceof String))
			return "";
		else {
			if (inData.equalsIgnoreCase("null") || inData.equals(" "))
				inData = "";
			return inData;
		}
	}
	
	public static String DecimalFormat (String inputNumber, String pattern){
		String formattedAmount = "";
		DecimalFormat formatter = new DecimalFormat();
		
		if(Validations.checkNull(inputNumber).equals("")){
			formattedAmount = "0.00";
		}else{
			formatter.applyPattern(pattern);
			formattedAmount = formatter.format(Double.parseDouble(inputNumber));
		}
		
		return formattedAmount;
	}
	
	public static String breakString(String strInputString , int numSize){
		String out = strInputString;
		try{
			if(strInputString.length()!=0 && strInputString.length() > numSize){
				out = strInputString.substring(0, numSize) + "...";
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}
		return out;
	}
	
	public static String checkNull(Object param,String strValue){
		 if(param != null){
			if(!param.toString().trim().equals(""))
				return param.toString();
			else
				return strValue;
		 }else
			return strValue;
	}
	
	public static String formatDate(Date date, String format){
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		String formattedDate = sdf.format(date); 
		return formattedDate;
	}
	
	public static int getASCIICode(char c){
		int ascii = (int) c;
		return ascii;
	}

	//	Encryption algorithm
	public static String encript(String val){
		boolean encFlag = GeneralPropsReader.getSingletonInstance().isEncFlag();
		if (!encFlag)
			return val;
		
		String s = val;
		String pw = IUOBConstant.ENC_DEC_KEY;
		int a=0;
		String myString="";
		int textLen=s.length();
		int pwLen=pw.length();
		for (int i=0;i<textLen;i++){
			a=new Integer(getASCIICode(s.charAt(i))).intValue();
			a=a^(getASCIICode(pw.charAt(i%pwLen)));
			String b=a+"";
			while (b.length()<3)
				b='0'+b;
			
			myString+=b;
		}
		return myString;
	}

	//	Decryption algorithm
	public static String decript(String val){
		boolean encFlag = GeneralPropsReader.getSingletonInstance().isEncFlag();
		if (!encFlag)
			return val;
		
		String s = val;
		String pw = IUOBConstant.ENC_DEC_KEY;
		List<Integer> list = new ArrayList<Integer>();
		String result = "";
		int a=0;
		int pwLen=pw.length();
		int i=0;
		String myHolder="";
		while(i<s.length()-2){
			myHolder=s.substring(i, i+1)+s.substring(i+1, i+2)+s.substring(i+2, i+3);
			if (s.charAt(i)=='0') {
				myHolder=s.substring(i+1, i+2)+s.substring(i+2, i+3);
			}
			if ((s.charAt(i)=='0')&&(s.charAt(i+1)=='0')) {
				myHolder=s.substring(i+2, i+3);
			}
			a=new Integer((myHolder)).intValue();
			a=a^(getASCIICode(pw.charAt(i/3%pwLen)));
			list.add(a);
			i+=3;
		}
		for (int j=0;j<list.size();j++){
			int ascci = ((Integer) list.get(j)).intValue();
			String aChar = new Character((char) ascci).toString();
			result = result + aChar;
		}
		return result;
	}
	
	

}
