package Utility;
import java.util.Properties;
import uoblog.UobLogManager;
import uobconstant.IUOBConstant;

public class GeneralPropsReader {
	
	private static GeneralPropsReader INSTANCE;
	private static final String CLASS_NAME = "GeneralPropsReader";
	private String hostUrl;
	private String onlineUrl;
	private String onlineContext;
	private String hostContext;
	private String gcnArn;
	private String apnsArn;
	private String awsPHPUtil;
	private String sendNotificationFileIOS;
	private String sendNotificationFileAndroid;
	private String pwdTxt;
	private boolean encFlag;
	
	private GeneralPropsReader(){
		init();
	}
 
	private void init() {
		String METHOD_NAME = "init()";
		
		Properties properties = new Properties();
	    try {
	    	String fileName = EnvIdentifier.getSingletonInstance().getEnvRelatedPropFileName("generalProps");
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "fileName: ["+fileName+"]");
	    	properties.load(GeneralPropsReader.class.getResourceAsStream(fileName));

	    	hostUrl = properties.getProperty(IUOBConstant.HOST_URL);
	    	onlineUrl = properties.getProperty(IUOBConstant.ONLINE_URL);
	    	onlineContext = properties.getProperty(IUOBConstant.ONLINE_CONTEXT);
	    	hostContext = properties.getProperty(IUOBConstant.HOST_CONTEXT);
	    	String encFlagStr = properties.getProperty(IUOBConstant.ENC_FLAG);
	    	encFlag = Boolean.valueOf(encFlagStr);
	    	
			UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "hostUrl: ["+hostUrl+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "onlineUrl: ["+onlineUrl+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "onlineContext"+onlineContext+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "hostContext: ["+hostContext+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "gcnArn: ["+gcnArn+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "apnsArn: ["+apnsArn+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "awsPHPUtil: ["+awsPHPUtil+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "pwdTxt: ["+pwdTxt+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "encFlagStr: ["+encFlagStr+"]");
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    
	}

	public static GeneralPropsReader getSingletonInstance() {
		String METHOD_NAME = "getSingletonInstance()";
		
		if (null == INSTANCE) {
			INSTANCE = new GeneralPropsReader();
		}
		
		return INSTANCE;
	}
	
	public String getHostUrl() {
		return hostUrl;
	}

	public void setHostUrl(String hostUrl) {
		this.hostUrl = hostUrl;
	}

	public String getOnlineUrl() {
		return onlineUrl;
	}

	public void setOnlineUrl(String onlineUrl) {
		this.onlineUrl = onlineUrl;
	}

	public String getOnlineContext() {
		return onlineContext;
	}

	public void setOnlineContext(String onlineContext) {
		this.onlineContext = onlineContext;
	}

	public String getHostContext() {
		return hostContext;
	}

	public void setHostContext(String hostContext) {
		this.hostContext = hostContext;
	}
	
	public String getGcnArn() {
		return gcnArn;
	}

	public void setGcnArn(String gcnArn) {
		this.gcnArn = gcnArn;
	}

	public String getApnsArn() {
		return apnsArn;
	}

	public void setApnsArn(String apnsArn) {
		this.apnsArn = apnsArn;
	}

	public String getAwsPHPUtil() {
		return awsPHPUtil;
	}

	public void setAwsPHPUtil(String awsPHPUtil) {
		this.awsPHPUtil = awsPHPUtil;
	}

	public String getSendNotificationFileIOS() {
		return sendNotificationFileIOS;
	}

	public void setSendNotificationFileIOS(String sendNotificationFileIOS) {
		this.sendNotificationFileIOS = sendNotificationFileIOS;
	}

	public String getSendNotificationFileAndroid() {
		return sendNotificationFileAndroid;
	}

	public void setSendNotificationFileAndroid(String sendNotificationFileAndroid) {
		this.sendNotificationFileAndroid = sendNotificationFileAndroid;
	}

	public String getPwdTxt() {
		return pwdTxt;
	}

	public void setPwdTxt(String pwdTxt) {
		this.pwdTxt = pwdTxt;
	}

	public boolean isEncFlag() {
		return encFlag;
	}

	public void setEncFlag(boolean encFlag) {
		this.encFlag = encFlag;
	}

}
