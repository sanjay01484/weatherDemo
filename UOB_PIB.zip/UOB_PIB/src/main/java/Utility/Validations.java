package Utility;

	import java.util.Random;
	import javax.servlet.http.HttpSession;
	import java.text.FieldPosition;
	import java.text.ParsePosition;
	import java.text.SimpleDateFormat;
	import java.util.Date;

	public class Validations {

		  public Validations() {}

		  /**
		   ** The method validates that the data contents are not null & returns empty string in case its 'null'
		   **/
		   public static boolean checkResult(String inData)
		   	{
		   		if(inData.equals("1"))
		   			return true;
		   		else
		   		{
		   			return false;
		   		}
		   	}


			 /**
			 ** The method validates that the data contents are not null & returns empty string in case its 'null'
			 **/
			 public static String checkNull(String inData)
			 	{
			 		if(inData == null)
			 			return "";
			 		else
			 		{
			 			if(inData.equalsIgnoreCase("null"))
			 				inData = "";
			 			return inData;
			 		}
			 	}
			 public static String getSysDate(String format)
				{
					/********DD/MM/YYYY ***************/
					String date = "";
				    java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat (format);
					java.util.Date currentTime_1 = new java.util.Date();
				    date = formatter.format(currentTime_1);
					return date;
				}
			 public static String getSysDate(HttpSession sess)
				{
					/********DD/MM/YYYY ***************/
					String date = "";
					try
					{
						String strtimeZoneDiff = checkNull(sess.getAttribute("_strTimeZoneDifferent"),"0");
						long timeZoneDiff = (long)(Float.parseFloat(strtimeZoneDiff) * 3600000);
						java.util.Date dCur = new java.util.Date();
						long lcur = dCur.getTime()+timeZoneDiff;
						java.util.Date ddCur = new java.util.Date(lcur);
						java.text.SimpleDateFormat sdfd = new java.text.SimpleDateFormat("dd/MM/yyyy");
						date = sdfd.format(ddCur);
					}catch(Exception e){}
					return date;
				}
			 public static String newDateFormat(String curFormat, String curDate, String newFormat)
				{
					//curFormat = "yyyy-MM-dd";
					//newFormat = "MM/dd/yyyy";
					//curDate = "2006-07-06";

					//fsi.Debug.println("curFormat ===> "+curFormat);
					//fsi.Debug.println("curDate   ===> "+curDate);
					//fsi.Debug.println("newFormat ===> "+newFormat);

					Date datCurrDate = new Date();
					StringBuffer sb = new StringBuffer();
					SimpleDateFormat sdfCurr;
					String newDate = "";

					if ((curFormat != null) && (curDate != null) && (newFormat != null) && (!curFormat.equals("")) && (!curDate.equals("")) && (!newFormat.equals("")))
					{
						if(curFormat.length() <= 10 ){
							 curFormat = curFormat.replace('m','M');
						}
						if(newFormat.length() <= 10 ){
							 newFormat = newFormat.replace('m','M');
						}
						sdfCurr = new SimpleDateFormat(curFormat);
						datCurrDate = sdfCurr.parse(curDate,new ParsePosition(0));

						sdfCurr = new SimpleDateFormat(newFormat);
						sb = sdfCurr.format(datCurrDate,new StringBuffer(),new FieldPosition(0));

						newDate = new String(sb);
					}
					//fsi.Debug.println("@@@@@newDate ===> "+newDate);
					return newDate;
				}
			 /**
			 ** The method validates that the data contents are not 'null' & returns replacement string in case its 'null'
			 **/
			 public static String checkNull(String inData,String strRplce)
			 {
			 	if(inData == null)
			 		return strRplce;
			 	else
			 	{
			 		if(inData.equalsIgnoreCase(""))
			 			inData = strRplce;
			 		else if(inData.equalsIgnoreCase("null"))
			 			inData = strRplce;

			 		return inData;
			 	}
			 }
			 public static String getSysDateTime(HttpSession sess,String format)
				{
					String dateTime = "";
					try
					{
						String strtimeZoneDiff = checkNull(sess.getAttribute("_strTimeZoneDifferent"),"0");
						long timeZoneDiff = (long)(Float.parseFloat(strtimeZoneDiff) * 3600000);
						java.util.Date dCur = new java.util.Date();
						long lcur = dCur.getTime()+timeZoneDiff;
						java.util.Date ddCur = new java.util.Date(lcur);
						java.text.SimpleDateFormat sdfd = new java.text.SimpleDateFormat(format);
						dateTime = sdfd.format(ddCur);
					}catch(Exception e){}
					return dateTime;
				}
			 public static String checkNull(Object param,String strValue)
				{
						if(param != null)
						{
							if(!param.toString().trim().equals(""))
								return param.toString();
							else
								return strValue;
						}
						else
							return strValue;
				}

			 /**
			 ** The method validates that the objects contents are not 'null' & returns replacement string in case its 'null'
			 **/
		 	 public static String checkNull(Object inData) {
				if (inData == null || !(inData instanceof String))
					return "";
				else {
					if (inData.toString().equalsIgnoreCase("null"))
						inData = "";
				}
				return inData.toString();
		 	}

		 	 private static final char[] HEX_CHARS = new char[]{'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};

		 		public static String hexString (byte nibbles) throws Exception
		 		{
		 		   return "" + HEX_CHARS [0x0F & (nibbles >> 4)] + HEX_CHARS [0x0F & nibbles];
		 		}

		 		public static String getHexString (byte[] nibbles) throws Exception
		 		{
		 			String hStr="";
		 			for(int i=0;i<nibbles.length;i++)
		 			{
		 				hStr = hStr+ hexString(nibbles[i]);
		 			}
		 			return hStr;
			}
			 		
			public String getCharImage() {
				String htmlString = "";
				try {
					String img[] = new String[5];

					char verCodeVal[] = new char[62];

					int j = 0;

					for (int i = 48; i <= 57; i++) {
						// 65-90 = A-Z ; 48-57 = 0-9 ; 97-122 = a-z
						verCodeVal[j++] = (char) i;
					}

					for (int i = 65; i <= 90; i++) {
						// 65-90 = A-Z ; 48-57 = 0-9 ; 97-122 = a-z
						verCodeVal[j++] = (char) i;
					}

					for (int i = 97; i <= 122; i++) {
						// 65-90 = A-Z ; 48-57 = 0-9 ; 97-122 = a-z
						verCodeVal[j++] = (char) i;
					}

					Random random = new Random();

					// Random integers that range from 0 to n
					int n = 62;

					String hidverCode = "";

					for (int i = 0; i < 5; i++) {
						int val = random.nextInt(n);

						hidverCode = hidverCode + verCodeVal[val];

						img[i] = val + ".gif";
					}

					htmlString = "<table border=\"0\" width=\"100%\" cellpadding=\"0\" cellspacing=\"0\"><tr><td width=\"35%\">";

					for (int i = 0; i < img.length; i++) {
						htmlString += "<img src=\"media/alimg/" + img[i]
								+ "\"  width=\"25\" height=\"25\">";
					}
					htmlString += "<input type=\"hidden\" name=\"txtVF\" value=\""
							+ hidverCode + "\"></td>";
					htmlString += "<td><img src=\"media/reload.jpeg\" alt=\"Regenerate\" title=\"Regenerate\" +" +
									"style=\"cursor: pointer;\" onclick=\"charChange();\"/></td></tr></table>";

				} catch (Exception ex) {
					System.out
							.println("Error in RegUserModelObject.getAjaxSummeryAmout()===> "
									+ ex);
					ex.printStackTrace();
				} finally {
					
				}
				
				return htmlString;
			}
			
			
			public static String checkNull(String inData,String strMain, String strRplce)
			 {
			 	if(inData == null)
			 		return strRplce;
			 	else
			 	{
			 		if(inData.equalsIgnoreCase(""))
			 			inData = strRplce;
			 		else if(inData.equalsIgnoreCase("null"))
			 			inData = strRplce;
			 		
			 		if(inData.equals(strMain)) {
			 			inData = strRplce;
			 		}

			 		return inData;
			 	}
			 }

}
