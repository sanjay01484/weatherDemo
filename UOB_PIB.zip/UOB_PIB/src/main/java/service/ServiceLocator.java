package service;
import interop.AuthCredentials;
import interop.Request;
import interop.Response;
import interop.User;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import uobconstant.IUOBConstant;
import uoblog.UobLogManager;
import Utility.Utils;
import Utility.Validations;
import exception.UOBBusinessException;
import exception.UOBCriticalException;

import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class ServiceLocator {
	
	private static ServiceLocator INSTANCE;
	static DataSource ds = null;
	private static final String CLASS_NAME = "ServiceLocator";
	
	private String fromEmailId;
	private String fromName;
	private String ccEmailId;
	private String mailDomain;
	private String mailHostPort;
	private String mailUserId;
	private String mailUserPassword;
	private String isSecure;
	private String requiresAuthentication;
	private String custCareMailId;
	
	private String socketFactoryPort;
	private String socketFactoryClass;
	private String smtpPort;
	
	private String OTP_PG_TIMEOUT;
	private String REFRESH_TIMEOUT;
	private String CC_PAGE_COUNTER;
	
	private ServiceLocator(){
		init();
	}

	private void init() {
		String METHOD_NAME = "init()";
		
		Properties properties = new Properties();
	    try {
	    	String fileName = EnvIdentifier.getSingletonInstance().getEnvRelatedPropFileName("servicelocator");
	    	properties.load(ServiceLocator.class.getResourceAsStream(fileName));
	    	String jndiName = properties.getProperty(IUOBConstant.DB_JNDI_NAME);
	    	String lookUpString = properties.getProperty(IUOBConstant.LOOK_UP_STRING);
	    	
	    	Context initContext = new InitialContext();
	    	Context envContext = (Context) initContext.lookup(lookUpString);
	    	
			ds = (DataSource) envContext.lookup(jndiName);
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Data Source: ["+ds+"]");
			
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "OTP_PG_TIMEOUT: ["+OTP_PG_TIMEOUT+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "REFRESH_TIMEOUT: ["+REFRESH_TIMEOUT+"]");
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "CC_PAGE_COUNTER: ["+CC_PAGE_COUNTER+"]");
						
			Properties smtpProperties = new Properties();
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "SMTP Properties : ["+smtpProperties+"]");

			
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    
	    UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from init()");
	}
	
	public DataSource getDatSource() throws SQLException{
		String METHOD_NAME = "getDatSource()";
		DataSource dataSource = null;
		if(ds != null)
			dataSource =  ds;
		
		return dataSource;
	}
	
	
	
	public static ServiceLocator getSingletonInstance() {
		String METHOD_NAME = "getSingletonInstance()";		
		if (null == INSTANCE) {
			INSTANCE = new ServiceLocator();
		}		
		return INSTANCE;
	}

	public String getFromEmailId() {
		return fromEmailId;
	}

	public void setFromEmailId(String fromEmailId) {
		this.fromEmailId = fromEmailId;
	}

	public String getCCEmailId() {
		return ccEmailId;
	}

	public void setCCEmailId(String ccEmailId) {
		this.ccEmailId = ccEmailId;
	}

	public String getMailDomain() {
		return mailDomain;
	}

	public void setMailDomain(String mailDomain) {
		this.mailDomain = mailDomain;
	}

	public String getMailHostPort() {
		return mailHostPort;
	}

	public void setMailHostPort(String mailHostPort) {
		this.mailHostPort = mailHostPort;
	}

	public String getMailUserId() {
		return mailUserId;
	}

	public void setMailUserId(String mailUserId) {
		this.mailUserId = mailUserId;
	}

	public String getMailUserPassword() {
		return mailUserPassword;
	}
	
	public void setMailUserPassword(String mailUserPassword) {
		this.mailUserPassword = mailUserPassword;
	}

	public String getIsSecure() {
		return isSecure;
	}

	public void setIsSecure(String isSecure) {
		this.isSecure = isSecure;
	}

	public String getRequiresAuthentication() {
		return requiresAuthentication;
	}

	public void setRequiresAuthentication(String requiresAuthentication) {
		this.requiresAuthentication = requiresAuthentication;
	}

	public String getSocketFactoryPort() {
		return socketFactoryPort;
	}

	public void setSocketFactoryPort(String socketFactoryPort) {
		this.socketFactoryPort = socketFactoryPort;
	}

	public String getSocketFactoryClass() {
		return socketFactoryClass;
	}

	public void setSocketFactoryClass(String socketFactoryClass) {
		this.socketFactoryClass = socketFactoryClass;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getCustCareMailId() {
		return custCareMailId;
	}

	public void setCustCareMailId(String custCareMailId) {
		this.custCareMailId = custCareMailId;
	}
	
	public String getOTP_PG_TIMEOUT() {
		return OTP_PG_TIMEOUT;
	}

	public String getREFRESH_TIMEOUT() {
		return REFRESH_TIMEOUT;
	}

	public String getCC_PAGE_COUNTER() {
		return CC_PAGE_COUNTER;
	}

}
