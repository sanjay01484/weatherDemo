package service;
import interop.Request;
import interop.Response;

public interface IServiceHandler {
	
	public Response execute(Request request);

}
