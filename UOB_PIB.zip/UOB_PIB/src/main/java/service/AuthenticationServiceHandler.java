package service;

import interop.Request;
import interop.Response;
import interop.User;
import interop.UserAuthInfo;
import interop.UserStmtDetails;
import uobconstant.IUOBConstant;
import uoblog.UobLogManager;
import DataModel.DataManager;
import Utility.Utils;
import exception.UOBBusinessException;
import exception.UOBCriticalException;
public class AuthenticationServiceHandler implements IServiceHandler{

	private static final String CLASS_NAME = "AuthenticationServiceHandler";
	
	@Override
	public Response execute(Request request) {
		String METHOD_NAME = "execute()";
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute");
		
		Response response = null;
		String function =  request.getFunction_Name(); 
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute AuthenticationServiceHandler "+function);
		if (IUOBConstant.FUNCTION_AUTHENTICATE.equals(function)){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute AuthenticationServiceHandler ");
			response = authenticate(request);
		}else if(IUOBConstant.FUNCTION_GET_USER_DETAILS.equals(function)){
			response = getUserDetails(request);
		}else if(IUOBConstant.FUNCTION_GET_TRANS_DETAILS.equals(function)){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute AuthenticationServiceHandler TRANS ");
			response = getUserTransDetails(request);
		}
		
		else if(IUOBConstant.FUNCTION_GET_DASHBOARD_DETAILS.equals(function)){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute AuthenticationServiceHandler DASHBOARD ");
			response = getUserDashBoardDetails(request);
		}
		else if(IUOBConstant.FUNCTION_SET_USERINSERT_DETAILS.equals(function)){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute AuthenticationServiceHandler Insert ");
			response = setUserInsert(request);
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From execute");
		return response;
	}
	
	private Response authenticate(Request request){
		String METHOD_NAME = "authenticate()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside Response authenticate()");
		
		Response response = null;
		DataManager dm = DataManager.getInstance();
		try{
			request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
			request.setFunction_Name(IUOBConstant.FUNCTION_AUTHENTICATE);
			response = dm.execute(request);
			User user = (User) response.get(IUOBConstant.USER_DETAILS_OBJECT);
			String errorCode = response.getResponseCode();
			user.setCusId(Utils.encript("12223333"));
				
				
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "response code: ["+response.getResponseCode()+"]");
		}catch(UOBCriticalException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(UOBBusinessException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(Exception ex){
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From authenticate()");
		return response;
	}
	
	private Response getUserDetails(Request request){
		String METHOD_NAME = "getUserDetails()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside getUserDetails()");
		
		Response response = null;
		DataManager dm = DataManager.getInstance();
		try{
			request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
			request.setFunction_Name(IUOBConstant.FUNCTION_GET_USER_DETAILS);
			response = dm.execute(request);
			//UserStmtDetails userDetInfoBean = (UserStmtDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
			String errorCode = response.getResponseCode();
			//user.setCusId(Utils.encript("12223333"));
				
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "response code: ["+response.getResponseCode()+"]");
		}catch(UOBCriticalException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(UOBBusinessException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(Exception ex){
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From getBrandPageDetails()");
		return response;
	}
	private Response getUserTransDetails(Request request){
		String METHOD_NAME = "getUserDetails()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside getUserDetails()");
		
		Response response = null;
		DataManager dm = DataManager.getInstance();
		try{
			request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
			request.setFunction_Name(IUOBConstant.FUNCTION_GET_TRANS_DETAILS);
			response = dm.execute(request);
			//UserStmtDetails userDetInfoBean = (UserStmtDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
			String errorCode = response.getResponseCode();
			//user.setCusId(Utils.encript("12223333"));
				
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "response code: ["+response.getResponseCode()+"]");
		}catch(UOBCriticalException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(UOBBusinessException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(Exception ex){
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From getBrandPageDetails()");
		return response;
	}
	
	private Response getUserDashBoardDetails(Request request){
		String METHOD_NAME = "getUserDetails()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside getUserDetails()");
		
		Response response = null;
		DataManager dm = DataManager.getInstance();
		try{
			request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
			request.setFunction_Name(IUOBConstant.FUNCTION_GET_DASHBOARD_DETAILS);
			response = dm.execute(request);
			//UserStmtDetails userDetInfoBean = (UserStmtDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
			String errorCode = response.getResponseCode();
			//user.setCusId(Utils.encript("12223333"));
				
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "response code: ["+response.getResponseCode()+"]");
		}catch(UOBCriticalException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(UOBBusinessException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(Exception ex){
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From getBrandPageDetails()");
		return response;
	}
	
	private Response setUserInsert(Request request){
		String METHOD_NAME = "setUserInsert()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside setUserInsert()");
		
		Response response = null;
		DataManager dm = DataManager.getInstance();
		try{
			request.setRequest_Type(IUOBConstant.AUTHENTICATE_SERVICE);
			request.setFunction_Name(IUOBConstant.FUNCTION_SET_USERINSERT_DETAILS);
			response = dm.execute(request);
			//UserStmtDetails userDetInfoBean = (UserStmtDetails) response.get(IUOBConstant.USER_STMT_DETAILS_OBJECT);
			String errorCode = response.getResponseCode();
			//user.setCusId(Utils.encript("12223333"));
				
			//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "response code: ["+response.getResponseCode()+"]");
		}catch(UOBCriticalException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(UOBBusinessException ex){		
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_BUSINESS_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}catch(Exception ex){
			response = new Response();
			response.setResponseCode(IUOBConstant.RESPONSE_CODE_CRITICAL_ERROR);
			response.setResponseMsg(ex.getMessage());
			
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}
		
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From getBrandPageDetails()");
		return response;
	}
	
	
}