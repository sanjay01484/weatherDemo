package service;

import interop.AuthCredentials;

public interface IAuthenticateService{

	
	public String authenticateUser(AuthCredentials product);
	public String getCustDTLS(AuthCredentials product);
 
} 
