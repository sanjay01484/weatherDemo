package service;

import java.net.InetAddress;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import interop.AuthCredentials;
import interop.Request;
import interop.Response;
import interop.User;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import uobconstant.IUOBConstant;
import uoblog.UobLogManager;
import Utility.Utils;
import Utility.Validations;
import exception.UOBBusinessException;
import exception.UOBCriticalException;

import java.sql.SQLException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
public class EnvIdentifier {

	private static EnvIdentifier INSTANCE;
	private static final String CLASS_NAME = "EnvIdentifier";
	private static Map<String, String> envMap = new HashMap<String, String>();
	
	private EnvIdentifier(){
		init();
	}

	private void init() {
		String METHOD_NAME = "init()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside init()");
		
		Properties properties = new Properties();
	    try {
	    	properties.load(EnvIdentifier.class.getResourceAsStream("multiEnv.properties"));
	    	Enumeration enuKeys = properties.keys();
			while (enuKeys.hasMoreElements()) {
				String key = (String) enuKeys.nextElement();
				String value = properties.getProperty(key);
				envMap.put(key, value);
				UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "key:["+key+"], value: ["+value+"]");
			}
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    
	    UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from init()");
	}
	
	public static EnvIdentifier getSingletonInstance() {
		String METHOD_NAME = "getSingletonInstance()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside getSingletonInstance()");
		
		if (null == INSTANCE) {
			INSTANCE = new EnvIdentifier();
		}
		
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from getSingletonInstance()");
		return INSTANCE;
	}
	
	public String getEnvHostName() {
		String METHOD_NAME = "getEnvHostName()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside getEnvHostName()");
		String hostName = "";
		String canonicalHostName = "";
		
		if (envMap != null) {
			try{
				InetAddress inetAddr = InetAddress.getLocalHost();
				hostName = inetAddr.getHostName();
				canonicalHostName = inetAddr.getCanonicalHostName();
				UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "hostName: ["+hostName+"]");
		    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "canonicalHostName: ["+canonicalHostName+"]");
			}catch(Throwable ex){
				UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Unable to identify IP Address of HOST"+Utils.getStackTrace(ex));
		    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Unable to identify IP Address of HOST"+Utils.getStackTrace(ex));
			}
		}
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from hostAddress: ["+hostName+"]");
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from getEnvHostName()");
		return hostName;
	}
	
	public String getEnvRelatedPropFileName(String fileName) {
		String METHOD_NAME = "getEnvRelatedPropFileName()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside getEnvRelatedPropFileName()");
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "fileName: ["+fileName+"]");
		String envFileName = "";
		String envName = "";
		
		String ipAddress = getEnvHostName();
		
		if (envMap != null) {
			envName = envMap.get(ipAddress);
			if (envName != null && envName.length()>0)
				envFileName = fileName + "_" + envName + ".properties";
			else
				envFileName = fileName + ".properties";
		}
		
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "envFileName: ["+envFileName+"]");
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from getEnvRelatedPropFileName()");
		return envFileName;
	}
	
	public String getEnvRelatedXMLFileName(String fileName) {
		String METHOD_NAME = "getEnvRelatedXMLFileName()";
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Inside getEnvRelatedXMLFileName()");
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "fileName: ["+fileName+"]");
		String envFileName = "";
		String envName = "";
		
		String ipAddress = getEnvHostName();
		
		if (envMap != null) {
			envName = envMap.get(ipAddress);
			if (envName != null && envName.length()>0)
				envFileName = fileName + "_" + envName + ".xml";
			else
				envFileName = fileName + ".xml";
		}
		
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "envFileName: ["+envFileName+"]");
		UobLogManager.writeToTrace(CLASS_NAME, METHOD_NAME, "Exit from getEnvRelatedXMLFileName()");
		return envFileName;
	}
}