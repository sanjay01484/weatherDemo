package service;
import interop.AuthCredentials;
import interop.Request;
import interop.Response;

import java.util.HashMap;
import java.util.Map;

import uobconstant.IUOBConstant;
import uoblog.UobLogManager;



public class ServiceHandler implements IServiceHandler {

	private static ServiceHandler INSTANCE;
	private static Map<String, Object> sMap = new HashMap<String, Object>();
	//private static final String FILE_NAME = "serviceHandlers.properties";
	private static final String CLASS_NAME = "ServiceHandler";
	
	public ServiceHandler(){
		init();
	}

	private void init() {
		String METHOD_NAME = "init()";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside init()");
		
	    try {
    		  AuthenticationServiceHandler authHandler = new AuthenticationServiceHandler();
    		
    		   
    		  sMap.put("AUTHENTICATE_SERVICE", authHandler);
    		  
    		  
	    }
	    catch (Exception e) {
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    	UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, e);
	    }
	    UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit From init()");
	}
	
	public static ServiceHandler getInstance() {				
		if (null == INSTANCE) {
			INSTANCE = new ServiceHandler();
		}		
		return INSTANCE;
	}
	
	@Override
	public Response execute(Request request){
		String METHOD_NAME = "execute";
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute sanjy33333");
		
		Response response = null;
		String request_type = request.getRequest_Type();
		AuthCredentials credentials = (AuthCredentials) request.get(IUOBConstant.AUTHENTICATE_CREDENTIAL_OBJECT);
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute sanjy33333"+request_type);
		//UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Inside execute sanjy33334443"+credentials.getEmail());
		 
		IServiceHandler serviceHandler = (IServiceHandler) sMap.get(request_type);
		try{
			response = (Response) serviceHandler.execute(request);
		}catch(Exception ex){
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
			UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, ex.getMessage());
		}	
		
		UobLogManager.writeToAudit(CLASS_NAME, METHOD_NAME, "Exit from execute");
		return response;
	}
}